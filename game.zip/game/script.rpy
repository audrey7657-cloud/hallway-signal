﻿############################################################
## script_with_illustration.rpy
## 「복도 끝의 신호」 — 일러스트 설계 반영본 (전 구간)
## - 매핑 테이블 기준: 배경 8종 / 이벤트 CG / t_, h_, s_, m_, y_, j_
## - 대사·내레이션·라벨·메뉴·변수·분기 로직은 일절 수정하지 않음
## - 캐릭터 dialogue 라인 직전에 scene + show 지시문만 정렬·추가
##
## [위치 약속]
##   담임(t)       : center
##   하린(h)       : center  (단, 가해 무리와 같이 있을 땐 right)
##   민재(m)       : left
##   예서(y)       : right
##   소윤(s)       : right   (하린과 단둘일 때는 left/center)
##   준호(j)       : right
############################################################

############################################################
## 캐릭터 정의
############################################################

define n = Character("나", who_color="#3A3A3A")

define h = Character("하린", who_color="#8B4A5A")
define s = Character("소윤", who_color="#4F6F52")
define m = Character("민재", who_color="#2F4F79")
define y = Character("예서", who_color="#9A5A3F")
define j = Character("준호", who_color="#5A5A7A")

define t = Character("담임 선생님", who_color="#2C3E50")
define pt = Character("체육 선생님", who_color="#6A4B2A")
define wt = Character("상담 선생님", who_color="#4A6F73")

define blink_black = Fade(0.08, 0.0, 0.12, color="#000")
define blink_black_long = Fade(0.15, 0.0, 0.28, color="#000")
define white_flash = Fade(0.08, 0.08, 0.45, color="#ffffff")

# 대사가 한 번에 뜨지 않고 자연스럽게 출력되도록 기본 속도를 지정합니다.
define config.default_text_cps = 35


transform wake_blur:
    xalign 0.5
    yalign 0.5
    zoom 1.03
    blur 4.0
    linear 0.6 blur 1.2 zoom 1.01

transform wake_clear:
    xalign 0.5
    yalign 0.5
    zoom 1.0
    blur 0.0



############################################################
## 이미지 선언
## 파일은 game 폴더 또는 images 폴더에 아래 이름으로 존재해야 함
############################################################

# 캐릭터 이미지

image t7 = "images/t7.png"
image t9 = "images/t9.png"
image pt1 = "images/pt1.png"
image y2 = "images/y2.png"
image y3 = "images/y3.png"
image y4 = "images/y4.png"
image y6 = "images/y6.png"
image y8 = "images/y8.png"
image y9 = "images/y9.png"

image h3 = "images/h3.png"
image h4 = "images/h4.png"
image h5 = "images/h5.png"
image h10 = "images/h10.png"
image h16 = "images/h16.png"
image h21 = "images/h21.png"
image h23 = "images/h23.png"
image h25 = "images/h25.png"
image h28 = "images/h28.png"

image j1 = "images/j1.png"
image j2 = "images/j2.png"

image m1 = "images/m1.png"
image m2 = "images/m2.png"
image m3 = "images/m3.png"
image m4 = "images/m4.png"
image m5 = "images/m5.png"
image m7 = "images/m7.png"
image m9 = "images/m9.png"
image m10 = "images/m10.png"
image m12 = "images/m12.png"

image s2 = "images/s2.png"
image s3 = "images/s3.png"
image s6 = "images/s6.png"
image s8 = "images/s8.png"
image s9 = "images/s9.png"
image s10 = "images/s10.png"
image s11 = "images/s11.png"

image t1 = "images/t1.png"
image t4 = "images/t4.png"
image t5 = "images/t5.png"
image t6 = "images/t6.png"


# 종이 / 소품 이미지

image cg_4 = "images/cg_4.png"
image cg_5 = "images/cg_5.png"
image cg_6 = "images/cg_6.png"
# UI 프로필 이미지

image profile_soyoon = "images/ui/profile_soyoon.png"


# 배경 이미지

image bg_1 = "images/bg_1.jpg"

image bg_2 = "images/bg_2.jpg"

image bg_3 = "images/bg_3.jpg"

image bg_4 = "images/bg_4.jpg"


image bg_5 = "images/bg_5.jpg"


image bg_6 = "images/bg_6.jpg"


image bg_7 = "images/bg_7.jpg"


image bg_8 = "images/bg_8.jpg"


image bg_9 = "images/bg_9.jpg"


image bg_10 = "images/bg_10.jpg"


image bg_11 = "images/bg_11.jpg"


image bg_12 = "images/bg_12.jpg"


image bg_13 = "images/bg_13.jpg"

image bg_14 = "images/bg_14.jpg"


image bg_15 = "images/bg_15.jpg"

image pe = "images/pe.png"


image bg_16 = "images/bg_16.jpg"


image bg_17 = "images/bg_17.jpg"

image bg_1_blur = Transform("images/bg_1.jpg", blur=5.0)
image bg_2_blur = Transform("images/bg_2.jpg", blur=5.0)
image bg_4_blur = Transform("images/bg_4.jpg", blur=5.0)
image bg_5_blur = Transform("images/bg_5.jpg", blur=5.0)
image bg_6_blur = Transform("images/bg_6.jpg", blur=5.0)
image bg_7_blur = Transform("images/bg_7.jpg", blur=5.0)
image bg_8_blur = Transform("images/bg_8.jpg", blur=5.0)
image bg_9_blur = Transform("images/bg_9.jpg", blur=5.0)
image bg_10_blur = Transform("images/bg_10.jpg", blur=5.0)
image bg_11_blur = Transform("images/bg_11.jpg", blur=5.0)
image bg_12_blur = Transform("images/bg_12.jpg", blur=5.0)
image bg_14_blur = Transform("images/bg_14.jpg", blur=5.0)
image bg_15_blur = Transform("images/bg_15.jpg", blur=5.0)
image bg_16_blur = Transform("images/bg_16.jpg", blur=5.0)
image bg_17_blur = Transform("images/bg_17.jpg", blur=5.0)
image pe_blur = Transform("images/pe.png", blur=5.0)
image cg_8_blur = Transform("images/cg_8.jpg", blur=5.0)
image cg_h1_blur = Transform("images/cg_h1.jpg", blur=5.0)

# CG 이미지

image cg_1 = "images/cg_1.jpg"
image cg_2 = "images/cg_2.jpg"
image cg_3 = "images/cg_3.jpg"
image cg_7 = "images/cg_7.jpg"
image cg_8 = "images/cg_8.jpg"
image cg_9 = "images/cg_9.jpg"

image cg_b1 = "images/cg_b1.jpg"
image cg_b2 = "images/cg_b2.jpg"
image cg_b3 = "images/cg_b3.jpg"

image cg_h1 = "images/cg_h1.jpg"
image cg_h2 = "images/cg_h2.jpg"

image cg_n1 = "images/cg_n1.jpg"

image cg_s1 = "images/cg_s1.jpg"
image cg_s2 = "images/cg_s2.jpg"
image cg_s3 = "images/cg_s3.jpg"
image cg_s4 = "images/cg_s4.jpg"

image cg_t1 = "images/cg_t1.jpg"
image cg_t2 = "images/cg_t2.jpg"
image cg_t3 = "images/cg_t3.jpg"
image cg_t4 = "images/cg_t4.jpg"


# 조사 화면 이미지

image classroom_r1_investigation = "images/classroom_r1_investigation.jpg"

############################################################
## 위치 transform
############################################################

transform center_stage:
    xalign 0.5
    yalign 1.0

transform left_stage:
    xalign 0.25
    yalign 1.0

transform right_stage:
    xalign 0.75
    yalign 1.0


# ------------------------------------------------------------
# 대화 장면용 약한 배경 블러
# ------------------------------------------------------------

transform bg_dialogue_blur:
    blur 2

transform bg_clear:
    blur 0

############################################################
## 시작 라벨
############################################################

label start:

    stop music fadeout 1.0
    # ------------------------------------------------------
    # 1. 시스템 및 신뢰도 초기화
    # ------------------------------------------------------
    $ loop_no = 0
    $ ending_type = ""
    $ trust_soyun = 0
    $ trust_harin = 0
    $ trust_minjae = 0

    # ------------------------------------------------------
    # 2. 교실/운동장 조사 플래그 초기화
    # ------------------------------------------------------
    $ inv_board = False
    $ inv_desk = False
    $ inv_back = False
    $ inv_pe_bottle = False
    $ inv_pe_bench = False
    $ talk_pe_harin = False
    $ talk_pe_minjae = False
    $ talk_pe_soyun = False
    $ talk_pe_yeseo = False
    $ r2_class_inv_initialized = False
    

    # ------------------------------------------------------
    # 3. 회차별 핵심 이벤트 및 선택지 플래그 초기화
    # ------------------------------------------------------
    $ f_minjae_talk_r2 = False
    $ f_r2_chat_with_soyoon = False
    $ f_r2_bath_soyoon_talk = False
    $ f_r2_soyoon_join = False
    $ f_r2_harin_connect = False
    $ f_r3_soyoon_coop = False
    $ f_r3_stay_together = False
    $ f_r3_teacher_support = False

    # ------------------------------------------------------
    # 4. 핵심 열쇠 및 단서 수첩 플래그 초기화
    # ------------------------------------------------------
    $ key1_structure = False
    $ key2_stay_with_harin = False
    $ key3_move_with_soyoon = False
    $ key4_minjae_pattern = False
    $ note_witness = False

    $ note_lunch = False
    $ note_photo = False
    $ note_bathroom = False
    $ note_note = False
    $ note_role = False

    $ chat_scroll_depth = 0
    $ f_r2_chat_checked = False
    $ note_chat = False

    show screen quick_note_button
    jump prologue_1

############################################################
## 프롤로그
############################################################

label prologue_1:
    # ------------------------------------------------------
    # 1. 교실 배경 출력
    # ------------------------------------------------------
    scene bg_1 with fade

    play sound "audio/bell.mp3"

    "종이 울렸다."
    "사물함으로 달려가는 발소리, 필통 지퍼 여는 소리, 의자 끄는 소리가 한꺼번에 터져 나왔다."

    # ------------------------------------------------------
    # 2. 선생님의 단호한 표정 등장
    # ------------------------------------------------------
    # 표 기준: t_1 = "조용. / 얘들아, 수업 시작하기 전에 먼저 말할 게 있어."
    
    stop sound fadeout 1.0
    scene bg_1_blur with dissolve
    show t1 at center_stage with dissolve
    t "조용."
    "선생님의 한마디에 모든 소리가 멈췄다."

    "선생님은 출석부를 품에 안은 채 교실을 한 번 천천히 둘러본 뒤 말을 이었다."
    hide t1 with dissolve
    show t5 at center_stage with dissolve
    t "얘들아, 수업 시작하기 전에 먼저 말할 게 있어."

    # 표 기준: t_2 = "하린이가 오늘부터 다른 학교로 가게 됐다."

    t "하린이가 오늘부터 다른 학교로 가게 됐다."
    hide t5 with dissolve
    "잠깐의 정적."


    scene bg_2 with dissolve
    "그리고 여기저기서 수군거림이 번졌다."

    # ------------------------------------------------------
    # 3. 아이들의 반응
    # ------------------------------------------------------
    scene bg_2_blur with dissolve
    # 표 기준: m_1 = "엥, 갑자기?" 외
  
    show m4 at left_stage with dissolve
    m "엥, 갑자기?"

    # 표 기준: y_1 = "그러고 보니 지난주에도 맨날 결석했잖아."
    show y8 at right_stage with dissolve
    y "그러고 보니 지난주에도 맨날 결석했잖아."
    hide m4 
    hide y8 
    with dissolve

    # 표 기준: j_1 = "그냥 이사간거겠지, 뭐."
    show j1 at center_stage with dissolve
    j "그냥 이사 간 거겠지, 뭐."
    hide j1 with dissolve

    "아이들은 그렇게 말하고 금세 다른 이야기로 넘어갔다."

    # ------------------------------------------------------
    # 4. 하린의 책상 클로즈업 (이벤트 CG)
    # ------------------------------------------------------
    scene cg_1 with dissolve

    "하지만 어쩐지 나는 하린의 자리에 시선이 갔다."
    "하린이 앉던 자리엔 이름표만 덩그러니 남아 있다."

    "언제부터였지."
    "저 자리가 비어 있는 게 당연해진 게."

    scene black
    with fade

    "하린이를 떠올려도 같이 떠오르는 장면이 하나도 없다는 게."

    "그런데 이상하게도, 딱 한 장면만큼은 머릿속에 또렷하게 남아 있었다."

    scene cg_2 with dissolve
    "축 처진 어깨. 어두운 눈. 빨갛게 부어 있던 눈가."
    "그게 내가 마지막으로 본 하린이의 모습이었다."

    scene black
    with fade

    jump prologue_2

label prologue_2:
    scene bg_3
    with fade

    "방과 후. 내 방."
    n "아…"

    play sound "audio/bed_sheets_moving.mp3"
    "가방을 바닥에 내려놓고 침대에 등부터 떨어뜨렸다."
    stop sound
    "천장을 올려다보는데 자꾸만 하린의 빈자리가 눈앞에 겹쳐 보였다."
    n "하린이는 왜 갑자기 전학을 갔을까."
    n "그날 왜 울었는지, 한 번이라도 물어볼걸 그랬나."
    n "…아니다, 내가 물어봤다고 해서 뭐가 달라졌겠어."
    n "그 전에, 나는 하린이에 대해 뭘 알고 있었지."

    "생각이 꼬리에 꼬리를 물다가 툭 끊겼다."
    with blink_black

    "눈꺼풀이 무거워졌다."
    with blink_black

    "하린이 마지막 모습을 떠올리면서 잠이 든다는 게 이상하다는 생각을 마지막으로,"
    with blink_black_long

    "눈앞이 흐려졌다."
    scene black
    with Dissolve(1.0)

    "멀리서 물 흐르는 소리."
    "누군가의 희미한 웃음소리. 짧게 울리는 진동음."
    "의자가 바닥을 날카롭게 긁는 소리가 점점 가까워졌다."
    "그리고"
    "모든 소리가 한순간에 끊겼다."
    scene black
    with fade
    "바로 귀 옆에서, 떨리는 목소리가 들려왔다."

    play sound "audio/heartbeat.mp3"
    scene cg_3 with dissolve
    h "너는… 봤잖아."
    stop sound fadeout 1.0

    jump scene0_investigation

############################################################
## 이하 장면은 기존 script.rpy 본문에 연결
############################################################


############################################################
## 조사 시스템 (1회차 진입)
############################################################

label scene0_investigation:
    scene black
    with fade

    # 눈 뜬 직후: bg_4가 흐릿하고 살짝 확대되어 보임
    scene bg_4_blur at wake_blur
    with white_flash

    pause 0.3

    n "헉!"
    "온몸에 소름이 돋았다."
    "분명 내 방 침대였는데."

    with blink_black

    "눈을 뜨니까 눈부신 햇살이랑 시끌벅적한 소리가 한꺼번에 들어왔다."

    with blink_black

    n "…학교?"
    "나는 내 책상에 엎드려 있었다."

    # 눈을 감았다 뜨면서 정상 크기, 정상 선명도 bg_4로 돌아옴
    scene bg_4 at wake_clear
    with blink_black_long

    n "뭐지? 꿈인가? 나 지금 왜 교실에 있지?"

    jump inv_loop_r1


label inv_loop_r1:

    scene bg_4 at wake_clear

    if inv_board and inv_desk and inv_back:
        jump inv_done_r1

    hide screen quick_note_button
    call screen class_investigation
    show screen quick_note_button

    if _return == "board":
        scene bg_4 with fade

        if not inv_board:
            $ inv_board = True
            "천천히 고개를 들어 칠판을 봤다."
            "오른쪽 구석에 날짜가 적혀 있었다."
            "< 5월 10일 월요일 >"
            n "5월 10일…?"
            n "말도 안 돼. 당번이 날짜를 안 바꿨나?"
            n "아니, 애초에 방에 있다가 갑자기 학교에 있는 게 말이 안 되잖아."
        else: 
            "칠판은 이미 확인했다."

        jump inv_loop_r1


    elif _return == "desk":
        scene bg_4 with fade

        if not inv_desk:
            $ inv_desk = True
            "무심코 고개를 돌렸다가 숨이 턱 막혔다."
            "하린이가 있었다."
            n "어… 전학, 갔잖아."
            "아침에 분명 선생님이 전학 갔다고 했는데, 자기 자리에 그대로 앉아 있었다."
            "고개를 푹 숙인 채 공책 위에 볼펜 끝으로 선을 긋고 있었다."
            "반복해서. 같은 자리에. 계속."
            n "이거 진짜 꿈이구나. 그러니까 전학 간 애가 보이지."
        else: 
            "하린이 자리는 이미 확인했다."

        jump inv_loop_r1


    elif _return == "back":

        scene bg_4 with fade

        if not inv_back:
            $ inv_back = True

            play sound "audio/punch.mp3"
            with vpunch
            "퍽."

            scene bg_4_blur with dissolve
            show m2 at center_stage with dissolve

            m "야, 정신 차려. 멍 때리는 거 꼭 오하린 같잖아."

            hide m2 with dissolve
            scene bg_4 with dissolve

            "민재가 내 어깨를 치고 지나갔다."
            "뒤쪽에서 웃음이 터졌다."
            n "왜 다들… 평소랑 똑같지?"
        
        else:
            "민재는 이미 친구들에게 돌아갔다."

        jump inv_loop_r1


    elif _return == "finish":
        if not (inv_board and inv_desk and inv_back):
            "아직 다 본 건 아닌 것 같지만,"
            "일단 이 상황이 뭔지부터 생각해 봐야겠다."
        jump inv_done_r1


    else:
        jump inv_loop_r1


label inv_done_r1:
    "몰래 허벅지를 꼬집어봤다. 아프다."
    "웃음소리, 책상에 닿는 팔 느낌, 창문으로 들어오는 바람."
    "모든 게 너무 생생했다."
    n "꿈이… 아니라고?"
    n "진짜 과거로 돌아왔다고? 하린이가 전학 가기 전으로?"
    "머릿속이 하얗게 비었다."
    "그때, 잠들기 전 귓가에 울렸던 하린의 목소리가 다시 떠올랐다."

    scene cg_3 with Dissolve(0.8)
    h "'너는… 봤잖아.'"

    scene bg_4 at wake_clear
    with Dissolve(0.6)

    n "…"
    n "무슨 상황인지 하나도 모르겠어. 아직도 꿈을 꾸는 건가?"
    "하지만 저기 하린이가 있다." 
    "돌아가기 전, 내가 마지막으로 봤던 그 모습 그대로."
    n "내가 당장 뭘 할 수 있는 상황이 아니야." 
    n "일단은… 이게 꿈이든 현실이든 지켜보는 수밖에 없어."

    jump loop1_start

############################################################
## 1회차 — 방관과 무력감의 굴레
############################################################

label loop1_start:
    $ loop_no = 1
    scene bg_4
    with fade

    "오전 수업은 어떻게 지나갔는지 기억나지 않는다."
    "선생님의 목소리도, 아이들의 웃음소리도 먹먹하게만 들렸다."
    "이게 정말 현실인지, 아주 긴 꿈을 꾸고 있는 건지 끝까지 알 수 없었다."
    
    play sound "audio/bell.mp3"
    "어느새 4교시 종료를 알리는 종이 울렸다."

    stop sound fadeout 1.0
    play sound "audio/children.mp3"
    "아이들이 의자를 끌며 우르르 급식실을 향해 빠져나갔다."    
    
    n "…일단 가보자."
    "나 역시 반쯤 떠밀리듯 아이들 틈에 섞여 걸음을 옮겼다."

    stop sound fadeout 1.0

    jump r1_s1_lunch

label r1_s1_lunch:
    $ note_lunch = True

    play sound "audio/children.mp3"
    scene bg_5 with fade
    "급식실은 평소처럼 시끌벅적했다."

    stop sound fadeout 1.0
    "맛있는 냄새랑 아이들 떠드는 소리가 가득한데," 
    "이상하게 자꾸 한쪽 테이블에 눈이 갔다."

    scene bg_6
    with dissolve
    "민재랑 예서네 무리가 앉아 있는 6인용 테이블이었다."
    "분명 자리가 하나 비어 있는데," 
    "예서의 겉옷이랑 민재의 가방이 그 자리를 꽉 차지하고 있었다."
    
    scene bg_6_blur with dissolve
    show h23 at center_stage with dissolve

    "하린이가 식판을 들고 그 자리 앞에 멈춰 섰다."
    "원래 친구가 오면 옷을 치워주거나 '여기 앉아'라고 할 텐데," 
    "아무도 하린이를 안 쳐다봤다."
    "민재는 어제 본 TV 프로그램 이야기를 하느라 바빴고, 예서는 깔깔거리며 웃고 있었다."

    hide h23 with dissolve
    scene bg_6 with dissolve

    "하린이는 잠시 그 자리에 서 있다가," 
    "아무 말 없이 몸을 돌려 멀리 떨어진 구석 자리로 걸어갔다."
    
    n "(분명 자리가 있었던 것 같은데.)"
    n "(아무도 옷을 안 치워주잖아?)"
    scene bg_6_blur with dissolve
    show s8 at center_stage with dissolve
    # 테이블에 앉아 눈치를 보던 소윤이의 반응 추가
    "그때 예서 옆에 앉아 있던 소윤이가 슬쩍 고개를 들어 하린이 뒷모습을 봤다."
    "소윤이는 뭔가 말하려는 듯 입을 벌렸다가, 다시 고개를 숙이고 밥만 먹었다."
    
    n "(소윤이는 무슨 말을 하려던 걸까.)"
    
    hide s8 with dissolve

    menu:
        "친한 애들끼리 앉으려고 그런 거겠지. 나도 내 자리에 앉자.":
            
            scene bg_6
            with dissolve
            
            "나는 그냥 평소 앉던 자리에 앉았다."
            "멀리서 혼자 밥을 먹는 하린이가 보였다."
            "그냥 '원래 혼자 먹는 걸 좋아하는 애인가?' 하고 넘기려 했지만,"
            "아까 그 자리에 놓여 있던 겉옷이 자꾸만 신경 쓰였다."

        "저기 자리 비어 있는데 옷 좀 치워주면 안 돼?":
            n "야, 민재야. 여기 자리 비었는데 옷 좀 옆으로 치워주면 안 돼?" 
            n "하린이 옆에 서 있었잖아."
            "내 말에 민재가 고개를 들어 나를 봤다."
            # 표 기준: m_3 = "아, 맞다. 여기 옷 있었네. 야, 김예서! 네 옷 좀 치워."
            scene bg_6_blur
            with dissolve 
            show m7 at center_stage with dissolve
            m "아, 맞다. 여기 옷 있었네. 야, 김예서! 네 옷 좀 치워."
            hide m7 with dissolve
            "민재가 귀찮은 듯 옷을 밀어냈지만, 하린이는 이미 저 멀리 구석으로 가버린 뒤였다."
            "내가 괜히 참견한 걸까?" 
            "분위기가 조금 썰렁해진 것 같아 마음이 불편했다."

        "나도 오늘 혼자인데, 하린이 옆에 가서 앉을까?":
            "나는 슬쩍 발걸음을 돌려 하린이가 앉은 구석 테이블로 향했다."

            scene bg_6_blur
            with dissolve
           
            "하린이는 구석 자리에서 혼자 조용히 밥을 먹고 있었다."
            "멍한 얼굴로 식판만 내려다보고 있었다."
            show h3 at center_stage with dissolve
           
            "내가 식판을 내려놓자, 하린이가 깜짝 놀라며 고개를 들었다."
            n "나 여기 앉아도 돼? 다른 데는 자리가 꽉 차서."
            hide h3 with dissolve
            show h16 at center_stage with dissolve
            h "…응. 앉아."

            "하린이는 조금 당황한 표정이었지만, 작게 고개를 끄덕였다."
            hide h16 with dissolve
            "특별한 대화는 없었지만," 
            "급식실이 덜 시끄럽게 느껴졌다."
    
    jump r1_s2_photo

label r1_s2_photo:
    $ note_photo = True
    scene black with fade

    scene bg_4 with fade

    "점심시간이 끝나갈 무렵의 교실."
    "밥을 먹은 아이들은 여기저기 모여 수다를 떨고 있었다."
    "나도 자리에 앉아 멍하니 창밖을 보며 쉬고 있던 참이었다."

    "그때, 창가 쪽에서 왁자지껄한 웃음소리가 터져 나왔다."
    "민재가 자기 핸드폰을 높이 들고 흔들고 있었다."

    scene bg_4_blur with dissolve

    # 민재: 사진 보여주며 조롱
    show m9 at left_stage with dissolve
    m "야, 이거 봐! 지난주 체육 시간에 오하린 자빠진 거. 표정 대박 아니냐?"


    # 준호: 실없게 웃음
    show j2 at right_stage with dissolve
    j "아, 뭐야 ㅋㅋㅋ 이거 연속 촬영으로 찍었어?"
    "준호는 별생각 없이 핸드폰 화면을 들여다보며 실없는 웃음을 터뜨렸다."
    "몰래 찍힌 사진이었는데, 거기서 심각하게 생각하는 애는 아무도 없었다."
    hide m9
    hide j2
    with dissolve

    # 예서: 말리는 척 동조
    show y2 at center_stage with dissolve
    y "야, 뭐 그런 걸 다 찍어~ 빨리 지워라."
    "예서는 말은 그렇게 하면서도 곁눈질로 화면을 보며 낄낄거렸다."
    "핸드폰은 가볍게 아이들 손을 타고 오갔다."
    hide y2 with dissolve

    scene bg_4 with dissolve
    n "어… 원래 저렇게 사진을 막 찍어서 돌려볼 만큼 하린이랑 친했나?"
    n "(아무리 봐도 친구끼리 하는 장난은 아닌데.)"
    n "전에도 이런 일이 있었나? 내가 그동안 관심이 없어서 몰랐던 건가?"
    "머릿속이 복잡해졌다. 평범해 보이던 교실 풍경이 낯설게 느껴졌다."

    # 소윤: 말 못 하고 눈치 보는 컷
    scene bg_4_blur with dissolve
    show s2 at center_stage with dissolve
    "그 무리 끝에 서 있던 소윤이도 조금 달랐다."
    "소윤이는 억지로 웃는 척하고 있었지만, 화면 쪽은 쳐다보지 않았다."
    "다른 아이들의 눈치를 슬쩍 살피더니, 슬며시 한 발짝 뒤로 물러섰다."
    hide s2 with dissolve

    # 하린은 여기서 꼭 스탠딩을 안 띄워도 되지만,
    # 분위기 강조하고 싶으면 아래 두 줄 사용 가능
    scene bg_4 with dissolve
    "교실 한구석."
    scene bg_4_blur with dissolve
    show h5 at center_stage with dissolve
    "웃음소리가 커질수록, 자기 자리에 앉은 하린이의 어깨는 조금씩 더 아래로 쳐졌다."
    "하린이는 필통 지퍼만 의미 없이 열었다 닫았다 했다."
    "아무 소리도 안 들리는 척, 이 시간이 빨리 지나가기만 바라는 것 같았다."
    hide h5 with dissolve
    "그 모습을 보고 있으니까, 목에 뭔가 걸린 것처럼 답답해졌다."
    scene bg_4 with dissolve

    menu:

        "내가 직접 본 것도 아닌데. 괜히 나섰다가 내가 이상한 애 되면 어떡해.":
            scene bg_7
            with dissolve
            "나는 시선을 피하고 교실 밖으로 나갔다."
            "복도를 걷는 동안에도 교실 안에서 터지는 웃음소리가 계속 따라왔다."
            "안 본다고 없어지는 게 아니라는 걸 알면서도,"
            "나는 멈추지 않고 걸었다."

        "저건 좀 심하잖아. 지우라고 말하자.":
            n "야, 허락도 안 받고 남의 사진 돌려보는 게 재밌어? 좀 지워."
            "시끌벅적하던 교실이 순식간에 찬물을 끼얹은 듯 조용해졌다."
            scene bg_4_blur
            with dissolve
            # 민재: 짜증/방어
            show m10 at left_stage with dissolve
            m "아, 씨. 왜 오버야? 그냥 장난친 건데."
            "민재가 투덜거리며 핸드폰을 주머니에 쑤셔 넣었다."
            hide m10 with dissolve
            show h4 at right_stage with dissolve
            "웃음소리는 멈췄지만, 정작 하린이는 쏟아지는 시선 속에서 고개를 더 깊이 파묻고 있었다."
            "내가 화를 낸 게 정말 하린이한테 도움이 된 건지 모르겠다."
            hide h4 with dissolve


        "하린이도 이 분위기 버티기 힘들 것 같다. 같이 나갈까.":
            "나는 하린의 책상 앞으로 걸어가 섰다."
            n "하린아, 잠깐 나가자. 바람 좀 쐬게."
            scene bg_4_blur
            with dissolve
            show h4 at center_stage with dissolve
            "하린이 민재 쪽을 불안하게 한 번 본 뒤, 작게 고개를 끄덕이며 일어섰다."
            hide h4 with dissolve
            scene bg_7
            with dissolve
            "복도 끝 자판기 앞."
            scene bg_7_blur
            with dissolve
            "하린은 뽑은 캔을 따지도 않은 채 라벨만 꾹꾹 누르고 있었다."
            n "…많이 불편했지."

            # 하린: 닫힌 반응
            show h3 at center_stage with dissolve
            h "…뭐. 신경 안 써."
            hide h3 with dissolve

            "음료수 캔을 쥐고 있는 하린의 손끝은 하얗게 질려 있었다."


    scene black with fade

    "그날 오후 수업은 어떻게 지나갔는지 기억도 나지 않는다."

    scene bg_3 with dissolve
    play sound "audio/bed_sheets_moving.mp3"
    "집에 와서 침대에 누웠는데도, 자꾸 하린이가 고개 숙이던 모습이랑" 
    "아이들 웃음소리가 머릿속에서 떠나지 않았다."
    stop sound
    n "(내가 너무 예민하게 받아들이는 건가. 그냥 애들끼리 친해서 장난치는 거겠지.)"
    n "(근데 왜 자꾸 이상한 기분이 드는 걸까.)"

    "답을 못 찾은 채 억지로 눈을 감았다."

    scene black with blink_black
    scene bg_3 with blink_black
    scene black with blink_black
    scene bg_3 with blink_black_long

    scene black with Dissolve(1.0)
    pause 1.0
    "꿈속에서도 누군가 계속 '너는 봤잖아'라고 속삭이는 것 같아서 자꾸 잠에서 깼다."

    scene black with fade
    pause 1.0
    jump r1_s5_bathroom

    label r1_s5_bathroom:
        $ note_bathroom = True

        scene bg_4 with fade
        "다음 날, 화요일 아침."
        "교실 문을 여는데 나도 모르게 숨을 크게 들이쉬었다."
        "어젯밤 꿈에서 들렸던 '너는 봤잖아'라는 속삭임이 아직도 귓가에 남아 있었다."
        "교실은 평소와 다름없이 시끄러웠다."
        "교실에 들어서자마자 나도 모르게 하린이 자리부터 봤다."
        scene bg_4_blur with fade
        show h23 at center_stage with dissolve
        "하린이는 엎드려 있었다. 어제보다 어깨가 더 작게 움츠러든 것 같았다."
        hide h23 with dissolve

        scene bg_4 with dissolve
        "수업이 시작되고 교과서를 펴는데, 갑자기 떠오른 생각 하나에 숨이 턱 막혔다."

        n "잠깐… 원래 하린이가 결석하기 시작한 날이 언제였지?"
        n "내일이야. 수요일부터 빈자리였다가… 다음 주 월요일에 전학 갔다고 했지."

        "그렇다면 내가 하린이를 직접 볼 수 있는 건 오늘이 마지막이라는 뜻이다."
        "심장이 불규칙하게 뛰기 시작했다."
        n "내일부터 당장 학교에 나오지 않는다고?"


        "1교시 내내 초조해서 다리를 떨었다."
        "칠판의 글씨는 하나도 들어오지 않았고, 시계 초침 소리만 이상하게 크게 들렸다."

        play sound "audio/bell.mp3"
        scene bg_7 with fade
        "쉬는 시간 종이 치자마자, 더 이상 못 버티고 무작정 복도로 빠져나왔다."


        stop sound fadeout 1.0
        scene bg_8 with dissolve
        "화장실 앞 복도 끝."
        scene bg_8_blur with dissolve
        show s3 at left_stage with dissolve
        "숨을 고르며 창밖을 보려는데, 화장실 문이 열리더니 소윤이가 먼저 걸어 나왔다."
        show h10 at right_stage with dissolve
        "그리고 그 뒤를 따라 하린이가 천천히 걸어 나왔다."

    
        "가까이서 본 하린이 얼굴에 머릿속이 하얘졌다."
        "눈가가 빨갛게 부어 있었고, 코끝도 빨개져 있었다."
        "방금 전까지 숨죽여 울고 있었던 게 분명했다."
        hide s3 with dissolve
        show s6 at left_stage with dissolve
        "소윤이는 그런 하린을 힐끗 보더니, 나와 눈이 마주치자 흠칫하며 시선을 피했다."


        "내일부터 하린이는 이 학교에 안 온다."
        "그 생각이 가슴을 꽉 누르는 것 같았다."
        hide s6 
        hide h10 
        with dissolve

        show s8 at left_stage 
        show h5 at right_stage 
        with dissolve
        "붉어진 눈으로 바닥만 보며 걷는 하린이와, 서둘러 내 옆을 스쳐 지나가려는 소윤이."
        "두 사람이 반대쪽으로 걸어가는 걸 보면서, 나는 입술을 꽉 깨물었다."

        menu:
            "서둘러 지나가려는 소윤이를 붙잡고 묻는다.":
                hide s8
                hide h5
                with dissolve
                scene bg_8 with dissolve
                n "소윤아, 잠깐만!"
                "내 옆을 지나치려는 소윤의 팔을 얼떨결에 잡았다."
                n "안에서 무슨 일 있었어? 너도 방금 같이 있었잖아."
                "당황하던 소윤의 얼굴이 금세 뾰족하게 굳어졌다."
                scene bg_8_blur with dissolve
                show s10 at center_stage with dissolve
                s "뭐? 내가 울린 거 아니야! 난 모른다고!"
                s "그렇게 참견하고 싶으면 네가 직접 가서 물어보든가."
                hide s10 with dissolve
                scene bg_8 with dissolve
                "소윤은 내 손을 거칠게 뿌리치고 교실로 가버렸다."
                "순식간에 벌어진 일에 나는 멍하니 서 있을 수밖에 없었다."

            "혼자 걷고 있는 하린이에게 다가가 말을 건다.":
                scene bg_8 with dissolve
                n "하린아..."
                scene bg_8_blur with dissolve
                show h16 at center_stage with dissolve
                "조심스럽게 다가가 부르자, 하린이가 화들짝 놀라며 뒷걸음질 쳤다."
                "눈물이 글썽이는 눈으로 나를 경계하듯 쳐다봤다."
                n "얼굴이 많이 안 좋은데... 보건실이라도 갈래?"
                hide h16 with dissolve
                show h10 at center_stage with dissolve
                h "그냥... 좀 내버려 둬."
                hide h10 with dissolve
                "하린이는 소매로 눈가를 벅벅 닦아내더니, 나를 지나쳐 반대쪽 계단으로 뛰어갔다."
                scene bg_8 with dissolve
                "도와주려고 뻗었던 손이 허공에서 멈췄다."

            "어떻게 해야 할지 모르겠다. 가만히 서 있는다.":
                scene bg_8 with dissolve
                "발이 바닥에 얼어붙은 것처럼 꼼짝도 하지 않았다."
                "누구에게 먼저 말을 걸어야 할지, 무슨 말을 해야 할지 머릿속이 하얬다."
                "내가 입술만 깨물며 망설이는 사이, 소윤이는 교실로 들어가 버렸고" 
                "하린이는 계단 아래로 사라졌다."
                "텅 빈 복도에 나 혼자 덩그러니 남겨졌다."
            
                "가슴이 답답하더니 이제는 목까지 꽉 막힌 것 같았다."

        scene black with dissolve
        "방금 복도에서 내가 다르게 행동했으면, 뭔가 달라졌을까?"

        scene bg_9 with fade
        "그날 3교시부터 하린이의 자리는 비어 있었다."
        "몸이 안 좋아 조퇴했다는 선생님의 짧은 설명이 전부였다."
        "뒤늦은 후회만 머릿속을 맴돌았다."
        
        scene black with fade
        pause 0.8
        jump r1_s6_note
# ----------------------------------------------------------
# R1-S6. 수요일 아침 — 결석과 서랍 속의 쪽지
# ----------------------------------------------------------
label r1_s6_note:
    $ note_note = True

    scene bg_9 with fade
    "다음 날, 수요일 아침."
    "하린이는 학교에 오지 않았다. 결석이었다."

    "아무도 없는 텅 빈 책상을 볼 때마다," 
    "어제 아무것도 못 했던 게 떠올라서 가슴이 답답했다."
    "아이들은 하린이가 오지 않은 것에 대해 아무도 묻지 않았다."
    "마치 처음부터 그 자리에 아무도 없었던 것처럼 교실은 평온했다."

    scene black with fade
    "1교시가 끝난 쉬는 시간."
    "자리에서 일어나다 실수로 지우개를 떨어뜨렸다."
    scene cg_1 with dissolve
    "데굴데굴 굴러간 지우개가 하필 하린이 빈 책상 밑에서 멈췄다."

    scene cg_8 with dissolve
    "몸을 숙여 지우개를 줍는데," 
    "하린이 책상 아래 떨어져 있는, 구겨진 종이가 눈에 띄었다."
    "쓰레기인가 보다 하고 무심코 집어 들었다."

    scene cg_8_blur with dissolve

    call screen interactive_note

    scene bg_9 with dissolve
    "손이 차갑게 식었다."
    "누가 장난으로 쓴 걸까? 아니, 장난이라기엔 기분이 너무 나빴다."
    n "'분위기 흐리지는 말자'라니... 대체 누구한테 쓴 거야?"

    scene cg_2 with dissolve
    "어제 화장실 앞에서 붉게 달아올랐던 하린이의 눈가가 자꾸 떠올랐다."
    scene black with dissolve
    "급식실에서 막혔던 자리, 아이들이 돌려보던 사진, 그리고 이 쪽지."
    "머릿속이 복잡해졌다. 대체 무슨 일이 벌어지고 있는 건지," 
    "이 쪽지가 뭘 뜻하는 건지 나로서는 알 수가 없었다."
    "하지만 뭔가 잘못되고 있다는 느낌은 확실했다."
    scene bg_9 with dissolve
    n "…이대로 그냥 두면 안 될 것 같아. 뭐라도 해야 해."


    "일단 선생님한테 이 쪽지라도 보여드려야겠다는 생각에 마음이 급해졌다."
    "나는 구겨진 종이를 손에 꽉 쥔 채 무작정 교실 뒷문으로 빠져나갔다."

    scene bg_10 with fade
    "쉬는 시간, 교무실."

    play sound "audio/door_open.mp3"
    "교무실 문을 열고 들어가자, 컴퓨터를 보며 타자를 치고 계시던 선생님이 고개를 드셨다."
    stop sound

    scene bg_10_blur with fade
    show t4 at center_stage with dissolve
    t "어, 웬일이야? 그렇게 급하게 뛰어오고."
    "선생님의 평범한 질문에 덜컥 말문이 막혔다."
    "쪽지를 쥔 손에 땀이 나는 게 느껴졌다."

    menu:
        "확실한 것도 없는데 괜히 말했다가 이상해질 것 같다. 일단 모른 척하자.":
            n "아… 아니에요. 그냥 교무실 심부름 온 애들 따라왔어요."
            "나는 쪽지를 쥔 손을 등 뒤로 슬그머니 감췄다."

            hide t4 with dissolve
            show t1 at center_stage with dissolve
            t "그래? 복도에서 뛰지 말고, 곧 종 치니까 얼른 교실 가봐."
            hide t1 with dissolve

            scene bg_10 with dissolve
            "용기를 내지 못했다."
            "나도 그걸 알고 있어서 교실로 돌아가는 발걸음이 무거웠다."

        "손에 쥔 쪽지를 보여주며, 지금까지 본 것들을 전부 말한다.":
            n "선생님, 하린이 자리에 이런 게 있었어요." 
            n "그리고 반 애들이 하린이 사진도 돌려보고, 자리도 막고…"
            
            hide t4 with dissolve
            show t7 at center_stage with dissolve
            "선생님의 표정이 굳어지며 내가 내민 구겨진 쪽지를 받아 들었다."
            t "이게 하린이 자리에 있었다고? 누가 넣었는지 혹시 봤니?"
            n "아니요, 그건 못 봤는데… 민재나 예서 무리가 계속…"
            "나는 말을 꺼냈지만, 뒤죽박죽이었다."
            "어떤 장면이 먼저였는지, 누가 무슨 말을 했는지 제대로 설명하기가 어려웠다."
            hide t7 with dissolve

            show t5 at center_stage with dissolve
            t "그래, 무슨 말인지 알겠어. 네가 말해준 건 그냥 넘길 일이 아니야."
            t "하지만 지금 바로 아이들을 불러서 몰아붙이면, 하린이가 더 곤란해질 수도 있어."
    
            t "먼저 하린이 안전을 확인하고,"
            t "네가 말해준 장면들은 선생님이 따로 기록해둘게."

            t "오늘부터 쉬는 시간, 급식 시간, 모둠 활동 때도 더 가까이서 볼 거야."
            t "그리고 필요하면 위클래스 선생님과도 함께 도울게."
            hide t5 with dissolve

        "쪽지를 숨긴 채, 반 분위기가 이상하다고만 돌려서 말한다.":
            n "저기… 요즘 하린이 주변 분위기가 좀 이상한 것 같아서요."
            "선생님이 키보드에서 손을 떼고 나를 바라보았다."

            hide t4 with dissolve
            show t7 at center_stage with dissolve
            t "분위기가? 구체적으로 누가 괴롭히기라도 하니?"
            n "딱 한 장면을 본 건 아닌데… 그냥 자꾸 애들이 하린이만 겉돌게 하는 것 같아서요."

            hide t7 with dissolve
            show t5 at center_stage with dissolve
            t "그렇구나. 하린이가 며칠 전부터 많이 지쳐 보이긴 하더라."

            t "그런 느낌도 중요한 신호니까 말해줘서 고마워."
            t "선생님이 좀 더 가까이서 신경 쓸게."
            hide t5 with dissolve

    jump r1_end

label r1_end:
    scene black with fade 
    pause 1.0
    scene bg_9 with fade
    "하지만 그날 이후, 하린의 자리는 계속 비어 있었다."
    "선생님은 종종 하린의 빈 책상을 근심 어린 눈으로 쳐다보셨다."
    "민재 무리는 전보다 더 시끄럽게 떠들었다."

    "선생님은 하린이에게 연락해 보겠다고 하셨고,"
    "내가 말한 장면들도 따로 적어 두겠다고 하셨다."
    "하지만 선생님이 확인하려고 해도," 
    "직접 물어볼 수 있는 하린이는 이미 사라진 뒤였다."

    "그제야 알 것 같았다."
    "이건 쪽지 하나의 문제가 아니었다."
    "그로부터 며칠 후,"

    scene black with dissolve
    "하린이가 결국 전학을 가게 되었다는 소식을 들었다."

    scene bg_3 with fade
    "그날 밤."
    play sound "audio/bed_sheets_moving.mp3"
    "침대에 누워 눈을 감으려는데, 자꾸만 하린이의 빈 책상과 붉게 달아오른 눈가가 떠올랐다."

    n "(내가 봤던 건 분명 이상했어.)"
    n "(그런데도 결국 아무것도 바꾸지 못했어.)"

    "잠이 들려는 찰나,"

    scene black with blink_black
    scene bg_3 with blink_black
    scene black with blink_black
    scene bg_3 with blink_black_long

    play sound "audio/heartbeat.mp3"
    "심장이 차갑게 조여드는 느낌과 함께 다시 그 목소리가 들려왔다."

    scene black with fade
    pause 1.5

    scene cg_7 with fade
    h "이상하다고 느꼈잖아."
    h "정말… 그때 한 번뿐이었어?"

    stop sound fadeout 1.0
    scene black with dissolve
    "어둠 속으로 끝없이 떨어지는 느낌이 온몸을 덮쳤다."

    scene black with fade
    pause 1.5

    jump loop2_start
############################################################
## 2회차 — 구조를 읽는 눈
############################################################
label loop2_start:
    scene black with fade
    pause 1.0

    $ loop_no = 2

    # 2회차 교실 조사 변수 초기화
    $ inv_board = False
    $ inv_desk = False
    $ inv_back = False
    $ r2_class_inv_initialized = False
    $ f_minjae_talk_r2 = False
    $ key1_structure = False

    # 회귀 직후 연출
    scene bg_4_blur at wake_blur
    with white_flash

    pause 0.3

    n "헉!"

    with blink_black

    "익숙한 교실 소음이 한꺼번에 귓가로 밀려들었다."

    with blink_black

    scene bg_4 at wake_clear
    with blink_black_long # 마지막 길게 뜨기

    "숨이 턱 끝까지 차올랐다. 책상에 엎드려 있던 몸을 황급히 일으켰다."
    
    n "하아... 하아..."
    
    "떨리는 고개를 들어 칠판을 확인했다."
    "< 5월 10일 월요일 >"
    
    n "말도 안 돼... 진짜 다시 돌아왔다고?"
    "두 번째 겪는 일인데도 머릿속이 새하얘졌다. 손끝이 차갑게 식었다."
    
    "어젯밤 귓가를 맴돌던 하린의 목소리가 다시 떠올랐다."
    scene cg_7 with dissolve
    "『이상하다고 느꼈잖아. 정말… 그때 한 번뿐이었어?』"
    scene bg_4 with dissolve
    n "아..."
    "그제야 깨달았다." 
    "쪽지 하나 주워 들고 교무실에 찾아갔던 내 행동은," 
    "정답이 아니었다는 걸."
    "이 상황 전체를 바꾸지 못하면, 어쩌면 나는." 
    "계속 이 시간 안에 갇히게 될지도 모른다."
    
    "크게 심호흡을 하며 떨리는 손을 꽉 쥐었다."
    n "침착하자. 지난번엔 너무 당황해서 눈에 보이는 것만 쫓았어."
    
    "시선을 돌려 교실 뒷자리를 쳐다봤다."
    "민재와 예서 무리가 평소처럼 떠들며 웃고 있었다."
    
    n "...그래. 이번엔 멀리서 지켜보기만 하는 게 아니라,"
    n "먼저 다가가서 직접 부딪혀봐야겠어."
    n "저 애들이 하린이한테 어떻게 구는지, 내 눈으로 직접 봐야 해."

    jump inv_loop_r2


label inv_loop_r2:

    if not r2_class_inv_initialized:
        $ inv_board = False
        $ inv_desk = False
        $ inv_back = False
        $ r2_class_inv_initialized = True

    if inv_board and inv_desk and inv_back and f_minjae_talk_r2:
        $ key1_structure = True

        n "대충 교실을 둘러보았다. 이전엔 보이지 않던 것들이 하나둘 눈에 들어온다."
        n "이건 어쩌다 한 번 일어난 장난이 아니야."
        n "하린이를 투명인간 취급하는 게 너무 '당연한 일상'이 되어버린 거야."
        n "이제 곧 수업 시작이다. 자리에 앉아야겠어."

        jump r2_s1_korean

    hide screen quick_note_button
    call screen class_investigation
    show screen quick_note_button

    if _return == "board":
        scene bg_4 with fade    

        if not inv_board:
            $ inv_board = True
            "칠판 날짜. < 5월 10일 월요일 >"
            "또 이 자리로 돌아왔다."
        else:
            "칠판은 이미 확인했다."

        jump inv_loop_r2

    elif _return == "desk":
        scene bg_4 with fade

        if not inv_desk:
            $ inv_desk = True
            "하린의 공책 위 선들. 자세히 보니 종이가 여러 군데 뚫려 있었다."
            "오늘 갑자기 생긴 흔적이 아니었다."

        else:
            "하린의 자리는 이미 확인했다."

        jump inv_loop_r2

    elif _return == "back":
        scene bg_4 with fade

        if not inv_back:
            $ inv_back = True
            "뒤쪽에서 민재와 예서 무리가 뭔가를 보며 웃고 있었다."
            "그 틈에서 하린의 이름이 스쳐 지나갔다."
            "저 웃음소리가 오늘 처음이 아니라는 걸, 이제는 안다."

        else:  
            "아이들은 이미 확인했다."
            
        jump inv_loop_r2

    elif _return == "minjae_r2":
        if not f_minjae_talk_r2:
            $ f_minjae_talk_r2 = True

            scene bg_4 with fade
            "무리에서 살짝 떨어져 있는 민재에게 다가갔다."

            n "저기, 민재야. 아까 보니까 예서랑 너네… 하린이 보면서 웃던데. 무슨 일 있어?"

            scene bg_4_blur with dissolve
            show m4 at center_stage with dissolve

            m "어? 아… 뭐. 그냥 좀 웃긴 일이 있어서 그런 건데." 
            m "왜? 네가 오하린한테 관심이 다 있었냐?"

            hide m4 with dissolve
            scene bg_4 with dissolve
            n "아니, 장난이라고 하기엔 하린이 표정이 너무 안 좋은 것 같아서 그래."

            scene bg_4_blur with dissolve
            show m1 at center_stage with dissolve

            m "아, 몰라! 쟤 원래 저런 표정 아니야?" 
            m "괜히 오버하지 마."

            hide m1 with dissolve
            scene bg_4 with dissolve
            
            $ trust_minjae += 1
            n "(민재는 당황하면 말을 돌리는구나. 생각보다 감추는 게 서툴러.)"
        else:
            scene bg_4 with fade
            "방금 민재와 대화를 나눴다. 지금은 더 다가가도 소득이 없을 것 같다."

        jump inv_loop_r2

    elif _return == "finish":
        if inv_board or inv_desk or inv_back:
            n "대충 교실을 둘러보았다. 이전엔 보이지 않던 것들이 하나둘 눈에 들어온다."
            
            if inv_board and inv_desk and inv_back:
                $ key1_structure = True
                n "이건 어쩌다 한 번 일어난 장난이 아니야."
                n "하린이를 투명인간 취급하는 게 너무 '당연한 일상'이 되어버린 거야."
        
        n "이제 곧 수업 시작이다. 자리에 앉아야겠어."
        jump r2_s1_korean

    else:
        jump inv_loop_r2

# ==========================================================
# R2-S1-2. 2회차 국어 시간 — 익숙한 소외
# ==========================================================
label r2_s1_korean:
    $ note_role = True

    scene black with fade
    pause 0.8

    scene bg_11 with fade

    "2교시 국어 시간. 선생님이 칠판에 '인물 분석 발표'라고 적으셨다."

    scene bg_11_blur with dissolve
    show t9 at center_stage with dissolve

    t "저번 시간에 정한 모둠대로 모여 앉아. 이번 발표는 모둠원 전원의 참여도가 중요해."

    hide t9 with dissolve
    scene bg_11 with dissolve

    "교실 여기저기서 의자 끄는 소리가 들렸다."
    "나도 우리 모둠 애들이랑 책상을 붙여 앉았는데, 자꾸 대각선 앞쪽 모둠이 신경 쓰였다."
    "하린, 민재, 소윤, 예서."

    "민재가 모둠의 중심에서 당연하다는 듯 역할을 나누기 시작했다."

    # 민재: 역할 분담 시작
    scene bg_11_blur with dissolve
    show m2 at left_stage with dissolve

    m "야, 예서 네가 발표하고 소윤이가 자료 조사해. 나는 대본 짤게."

    show s2 at right_stage with dissolve
    s "어? 그럼 하린이는...?"

    "소윤이의 물음에 민재는 하린이를 보지도 않고 대답했다."
    m "오하린? 쟤는 그냥 자료 정리해서 메일로 보내라고 해. 어차피 말도 잘 안 하잖아."

    hide m2
    hide s2
    with dissolve

    show h3 at center_stage with dissolve

    "하린이는 아무 말 없이 책상 아래로 손을 꼭 쥐고 있었다."
    "나는 내 모둠 활동지를 내려다보며 어떻게 해야 할지 고민했다."

    menu:
        "민재의 말에 직접 끼어든다. \"하린이 의견도 들어봐야 하는 거 아냐?\"":
            $ trust_harin += 1
            $ trust_minjae -= 1

            hide h3 with dissolve
            scene bg_11 with dissolve
            "나는 결국 참지 못하고 한마디를 던졌다. 민재가 귀찮다는 듯 고개를 돌렸다."

            scene bg_11_blur with dissolve
            show m10 at left_stage with dissolve
            m "아, 넌 네 모둠이나 신경 써. 하린아, 너도 이게 편하지?"
            
            show h16 at right_stage with dissolve
            h "…어, 응. 나 괜찮아."
            hide m10
            hide h16 
            with dissolve
            scene bg_11 with dissolve

            "도와주려고 했는데, 하린이는 오히려 더 난처한 표정으로 나를 피했다."
            n "(하린이가 내 도움을 부담스러워하고 있어. 내가 너무 성급했나?)"

        "소윤이에게 말을 건다. \"소윤아, 너희는 역할 분담 다 끝났어?\"":
            $ trust_soyun += 1

            hide h3 with dissolve
            scene bg_11 with dissolve
            "나는 일부러 소윤이에게 말을 걸어 분위기를 환기하려 했다."

            scene bg_11_blur with dissolve
            show s8 at center_stage with dissolve
            s "어? 아… 응. 민재가 일단 이렇게 하자고 해서."

            n "하린이가 할 일이 너무 적은 거 아냐? 나중에 참여도 점수 깎일까 봐 걱정돼서 그래."
            "소윤이는 내 말에 하린이와 민재를 번갈아 봤다." 
            "어떻게 해야 할지 모르겠다는 표정이었다."
            hide s8 with dissolve
            show s3 at center_stage with dissolve
            s "…그렇지? 그래도 뭐... 이미 정한걸."
            hide s3 with dissolve
            scene bg_11 with dissolve

            "소윤이의 눈빛이 흔들렸다."

        "우리 모둠 일이나 하자. 일단은 지켜보는 수밖에 없어.":
            $ key1_structure = True

            hide h3 with dissolve
            scene bg_11 with dissolve

            "나는 애써 시선을 돌려 우리 모둠의 활동지를 읽기 시작했다."
            "옆 모둠에서는 민재와 예서의 웃음소리가 들려왔고," 
            "하린이는 그 안에서 투명인간처럼 앉아 있었다."
            n "(저건 그냥 효율적인 역할 분담이라고 하기엔 너무 이상해.)" 
            n "(왜 아무도 잘못됐다고 말하지 않는 거지?)"
            n "(그렇지만... 나조차도 가만히 있기만 한걸.)"

    # 공통 마무리
    scene black with fade
    "결국 하린이 모둠의 역할 분담은 그대로 끝났다."
    "하린이는 끝까지 고개를 들지 않고 교과서 모서리만 만지작거렸다."
    jump r2_s2_lunch

# # ----------------------------------------------------------
# R2-S2. 2회차 점심시간 — 억지로 뭉친 아이들
# ----------------------------------------------------------
label r2_s2_lunch:
    scene black with fade

    play sound "audio/bell.mp3"
       
    scene bg_5 with dissolve
    "오전 수업이 끝나는 종이 울렸다."
    stop sound fadeout 1.0
    "처음 이 날을 겪었을 때는 아무 생각 없이 애들 틈에 껴서 급식실로 갔었다."
    "하지만 이번엔 달랐다." 
    "식판을 받자마자 교실 뒷자리 애들이 모여 있는 곳부터 찾았다."
    
    scene bg_6 with dissolve
    "대각선 앞쪽, 6인용 테이블."
    "민재, 예서, 준호, 그리고 소윤이가 모여 앉아 있었다."
    "똑같이, 하나 남은 빈 의자 위에는 예서의 겉옷이 떡하니 올려져 있었다."

    scene bg_5_blur with dissolve
    show h3 at center_stage with dissolve
    "배식을 받은 하린이가 그 테이블 앞을 지나갔다."
    "아무도 하린이를 쳐다보지 않았다." 
    "하린이를 없는 사람 취급하는 게 너무 자연스러워 보여서 더 이상했다."

    hide h3 with dissolve
    scene bg_6 with dissolve
    "저번에는 그저 '분위기가 좀 이상하다' 하고 넘겼던 장면이다." 
    "하지만 이제는 확실히 보였다."

    n "(대놓고 하린이가 앉을 자리를 막고 있어.)" 
    n "(그런데 주변에서 밥 먹는 애들도 다 모른 척하고 있잖아?)"
    n "(아무도 뭐라고 안 하니까, 예서랑 민재가 더 당당하게 저러는 거야.)"


    "내 시선은 테이블 끝에 앉은 소윤이에게 향했다."
    scene bg_6_blur with dissolve
    show s8 at center_stage with dissolve
    "소윤이는 저번처럼 밥만 깨작거리며," 
    "멀어지는 하린이의 뒷모습을 슬쩍 훔쳐보고 있었다."

    n "소윤이도 지금 상황이 잘못됐다는 걸 알고 있는 것 같아."
    

    hide s8 with dissolve
    scene bg_6 with dissolve    
    "나는 제자리에 서서 식판을 꽉 쥐었다."
    "이번엔 어떻게 해야 할까?"

    menu:
        "나서봤자 피곤해지기만 할 것 같아. 조용히 내 밥이나 먹자.":
            scene bg_6_blur with dissolve
            "나는 못 본 척 시선을 거두고 내 자리에 앉았다."

            "하린이는 멀리서 묵묵히 혼자 식판을 비웠다."

            "나 하나 조용히 넘어간다고 당장 큰일이 나진 않겠지만..."
            "왠지 나도 저 애들의 행동을 괜찮다고 해준 것 같은 찝찝함이 목에 걸렸다."
            jump r2_s2_pe

        "다들 너무하잖아. 당장 옷부터 치우라고 따져야겠어.":
            scene bg_6_blur with dissolve
            n "야, 옷 좀 치워! 하린이가 못 앉잖아!"
            "내 날카로운 외침에 웅성거리던 급식실이 순간 찬물을 끼얹은 듯 조용해졌다."

            show m10 at center_stage with dissolve
            m "아씨, 밥 먹는데 깜짝 놀랐네. 야, 오하린! 여기 앉을거야?"
            hide m10 with dissolve
            "민재가 신경질적으로 겉옷을 낚아채며, 멀어지던 하린이 쪽을 홱 노려보았다."
            show h4 at center_stage with dissolve
            "갑자기 자기 이름이 불리자 놀라서 우뚝 멈춰 섰던 하린이의 얼굴이 하얗게 질려 있었다."
            "순식간에 식당 안 아이들의 시선이 나와 하린이에게 번갈아 쏠렸다."

            hide h4 with dissolve
            "결국 하린이는 빈자리로 올 생각조차 못한 채," 
            "아이들에게서 멀찍이 떨어진 테이블로 쫓겨나듯 앉았다."
            "도와주려는 마음만 앞서서, 하린이를 오히려 더 당황하게 만들어버렸다."
            jump r2_s2_pe

        "소윤이도 볼 수 있게, 당당하게 하린이 옆으로 가서 앉자.":
            $ trust_soyun += 1
            "나는 식판을 들고 하린이가 있는 구석 자리로 성큼성큼 걸어갔다."

        
            n "하린아, 나 여기 앉는다?"
            scene bg_6_blur with dissolve
            show h16 at center_stage with dissolve
            "내가 일부러 조금 큰 소리로 말하며 맞은편에 앉자, 하린이가 깜짝 놀라 고개를 들었다."
            hide h16
            show h5 at center_stage with dissolve
            h "…어. 응."

            "슬쩍 고개를 돌려 6인용 테이블 쪽을 살폈다."
            hide h5 with dissolve
            show s2 at center_stage with dissolve
            "소윤이는 숟가락을 입에 문 채로, 아주 복잡한 표정으로 이쪽을 빤히 바라보고 있었다."
            hide s2 with dissolve
            scene bg_6 with dissolve

            jump r2_s2_pe

# ----------------------------------------------------------
# R2-S2. 2회차 오후 — 운동장의 그림자
# ----------------------------------------------------------
label r2_s2_pe:
    scene black with dissolve
    pause 0.5
    scene pe with fade

    "5교시 체육 시간. 운동장으로 나가는 아이들의 발걸음이 가벼웠지만, 내 마음은 여전히 무거웠다."

    "선생님이 호루라기를 불며 외치셨다."
    scene pe_blur with fade
    show pt1 at center_stage with dissolve
    pt "자, 오늘은 2인 1조로 배드민턴 연습한다. 각자 짝 정해서 줄 서!"

    hide pt1 with dissolve
    scene pe with dissolve
    "그 말이 떨어지기 무섭게 아이들이 움직였다."
    "민재와 준호가 하이파이브를 하며 짝이 되었고, 예서와 소윤이도 자연스럽게 옆에 섰다."

    scene pe_blur with dissolve
    show h5 at center_stage with dissolve
    "하린이는 아무도 쳐다보지 않는 나무 그늘 쪽으로 시선을 피하며 뒷걸음질 쳤다."
    
    hide h5 with dissolve
    scene pe with dissolve
    n "(저번에는 나도 내 짝을 찾느라 저렇게 서 있는 하린이를 못 봤었지.)"
    n "(결국 하린이는 남는 애가 없어서 선생님이랑 짝을 했었어. 그게 얼마나 창피했을까.)"

    "나는 친구들이 부르는 소리를 뒤로하고 하린이에게 다가갔다."
    n "하린아, 나랑 짝 하자."

    scene pe_blur with dissolve
    show h4 at center_stage with dissolve
    "하린이는 고맙다는 표정 대신, 잔뜩 겁을 먹은 얼굴로 멀리 있는 예서 무리의 눈치를 살폈다."
    h "…어? 아, 응. 그래."
    hide h4 with dissolve
    scene pe with dissolve

    "짝이 되어 함께 연습을 시작했지만, 숨 막히는 상황은 나아지지 않았다."
    "바람에 날려 우리 쪽으로 굴러온 셔틀콕을 하린이가 주워서 돌려주려 하자," 
    "민재는 하린이의 손이 닿기도 전에 라켓으로 홱 긁어가듯 공을 낚아챘다."
    "그러고는 더럽다는 듯 바지춤에 손을 쓱쓱 닦으며 무리 쪽을 돌아보고 픽 웃었다."
    "예서와 아이들은 입을 가린 채 자기들끼리 눈을 맞추며 큭큭거렸다."

    "아무도 하린이를 때리거나 욕하지 않았다."
    "그냥 더럽다는 듯이 피했을 뿐이다."
    "그런데 그게, 때리는 것보다 더 아파 보였다."

    n "(옆에 있어 주는 것만으로는 이 답답한 분위기를 바꿀 수 없어.)"
    n "(내가 안 보는 곳, 선생님 눈이 닿지 않는 곳에서는 대체 어떤 일들이 벌어지고 있는 걸까?)"

    scene black with fade
    jump r2_s2_pe_investigation

############################################################
## R2-S2-PE-INV. 2회차 체육 조사 진입
############################################################
label r2_s2_pe_investigation:
    scene bg_12 with fade

    "선생님이 잠시 공을 챙기러 간 사이, 자유 연습 시간이 시작되었다."
    "아이들은 끼리끼리 모여 쑥덕거리거나 배드민턴을 쳤다."
    n "지금이야. 선생님도 안 계시고 애들도 자기들끼리 노느라 정신없을 때..."
    n "조금 더 가까이서 확인해 봐야겠어." 
    n "뭐 때문에 이렇게 이상한 느낌이 드는지."

    $ inv_pe_bottle = False
    $ inv_pe_bench = False
    $ talk_pe_minjae = False
    $ talk_pe_soyun = False
    $ talk_pe_harin = False
    $ talk_pe_yeseo = False

    jump pe_investigation_loop



############################################################
## R2-S2-PE-INV. 2회차 체육 조사 루프
############################################################
label pe_investigation_loop:

    if inv_pe_bench and talk_pe_yeseo and talk_pe_harin and talk_pe_minjae and talk_pe_soyun:
        jump pe_investigation_finish

    call screen pe_investigation_screen

    if _return == "bench":
        scene bg_12 with fade

        if not inv_pe_bench:
            $ inv_pe_bench = True
            "벤치 주변 모래바닥에 대충 그어진 낙서들이 보였다."
            "『오하린 냄새남』, 『투명인간』"
            "방금 쓴 것처럼 선명했다."
            "내가 하린이랑 짝을 하는 동안에도, 누군가는 이걸 쓰고 있었다는 뜻이다."
        else:
            "벤치 주변 낙서는 그대로 남아 있다."
            "아무도 지우지 않았고, 아무도 이상하게 여기지 않는 것 같다."

        jump pe_investigation_loop


    elif _return == "yeseo":
        scene bg_12 with fade

        $ talk_pe_yeseo = True

        "예서는 민재 옆에서 웃고 있었다."
        "직접 나서서 뭔가를 하는 것처럼 보이지는 않았다."
        "하지만 민재가 웃을 때마다 같이 웃고, 하린 쪽으로는 일부러 시선을 주지 않았다."

        jump pe_investigation_loop


    elif _return == "harin":

        if not talk_pe_harin:
            $ talk_pe_harin = True
            $ f_r2_harin_connect = True

            scene bg_12 with fade

            "라켓을 꼭 쥔 채 내 눈치만 보고 있는 하린이에게 다가갔다."
            n "하린아, 힘들면 좀 쉴래? 물 마시고 와."

            scene bg_12_blur with dissolve
            show h16 at center_stage with dissolve

            h "아니야... 나 괜찮아. 나 때문에 너까지 애들이랑 못 노는 거 아냐?"

            hide h16 with dissolve
            scene bg_12 with dissolve

            "하린이는 미안해하면서도 내가 옆에 있다는 사실에 조금은 안심한 듯 보였다."

            $ trust_harin += 1

            "하린이의 굳어있던 어깨가 아주 조금 내려간 것 같다."

        else:
            scene bg_12 with fade
            "하린이는 조금 진정된 표정으로 라켓을 만지작거리고 있다."
            "지금은 가만히 두는 게 나을 것 같다."

        jump pe_investigation_loop


    elif _return == "minjae":

        if not talk_pe_minjae:
            $ talk_pe_minjae = True

            scene bg_12 with fade

            "친구들과 낄낄거리던 민재에게 슬쩍 다가갔다."
            n "민재야, 아까 셔틀콕 줄 때... 꼭 그렇게 뺏어가야 했어?" 
            n "하린이 다칠 뻔했잖아."

            if f_minjae_talk_r2:
                scene bg_12_blur with dissolve
                show m1 at center_stage with dissolve

                m "아, 씨... 아까부터 진짜 왜 이래? 너 내가 만만하냐?"

                hide m1 with dissolve
                scene bg_12 with dissolve

                "민재가 평소보다 더 크게 소리를 질렀다."
                "주변 아이들의 시선이 우리 쪽으로 쏠렸다."
                "하지만 민재는 예전처럼 당당하게 웃지 못했다."
                "오히려 얼굴이 붉어진 채 라켓을 쥔 손으로 바지춤을 쓱쓱 닦아낼 뿐이었다."

                n "(소리만 크게 지르는 거 보니까,)"
                n "(자기도 창피한 줄 아는 거네.)"

                "민재는 잠깐 말을 잇지 못했다."
                "이번에는 장난이라는 말도 쉽게 나오지 않는 듯했다."

                $ key4_minjae_pattern = True

                "민재는 고개를 숙인 채 한동안 아무 말도 하지 않았다."

            else:
                scene bg_12_blur with dissolve
                show m7 at center_stage with dissolve

                m "아, 뭐래. 그냥 빨리 치려고 그런 거지." 
                m "너 왜 자꾸 나만 갖고 그래?"

                hide m7 with dissolve
                scene bg_12 with dissolve

                "민재는 짜증 난 목소리로 말했지만, 내 눈을 오래 보지는 못했다."
                "아직은 자기 말이 맞다고 우기고 싶은 것 같았다."

            $ trust_minjae += 1

        else:
            scene bg_12 with fade
            "민재는 이제 내 쪽을 아예 쳐다보지도 않는다."
            "하지만 아까의 대화가 신경 쓰이는지 자꾸 라켓만 만지작거린다."

        jump pe_investigation_loop


    elif _return == "soyun":

        if not talk_pe_soyun:
            $ talk_pe_soyun = True

            scene bg_12 with fade

            "예서 옆에서 곤란한 표정으로 서 있던 소윤이와 눈이 마주쳤다."
            "소윤이는 흠칫 놀라며 시선을 피하려 했다."

            n "소윤아, 너도 아까 다 봤지? 저건 좀 너무한 거 아니야?"

            scene bg_12_blur with dissolve
            show s3 at center_stage with dissolve

            s "나... 나는 그냥... 모르겠어."

            hide s3 with dissolve
            scene bg_12 with dissolve

            "소윤이는 대답을 피하며 도망치듯 자리를 옮겼다."

            $ trust_soyun += 1

        else:
            scene bg_12 with fade
            "소윤이는 예서의 말에 건성으로 맞장구만 치고 있다."

        jump pe_investigation_loop


    elif _return == "finish":
        jump pe_investigation_finish


    else:
        jump pe_investigation_loop


label pe_investigation_finish:

    scene bg_12 with fade

    if inv_pe_bench and talk_pe_minjae and talk_pe_soyun:
        n "대충 알 것 같아. 이건 그냥 애들이 한두 번 장난치는 수준이 아니야."
        n "다들 조금씩 하린이가 혼자 남게 만들고 있었어." 
        n "소윤이조차 아무 말도 못 하고..."
        n "이제 뭔가 조금씩 보이는 것 같아." 
        n "집에 가서 다시 생각해봐야겠어."
    else:
        n "이제 뭔가 조금씩 보이는 것 같아." 
        n "집에 가서 다시 생각해봐야겠어."

    jump r2_s3_home
# ----------------------------------------------------------
# R2-S3. 2회차 방과 후 — 보이지 않는 교실 (단톡방)
# ----------------------------------------------------------
label r2_s3_home:
    scene black with fade
    scene bg_3 with fade

    $ chat_scroll_depth = 0
    $ f_r2_chat_checked = False

    play sound "audio/bed_sheets_moving.mp3"
    "학교가 끝나고 집에 돌아왔지만, 침대에 누워서도 낮의 일들이 계속 머릿속을 맴돌았다."
    stop sound
    n "내가 오늘 하린이 옆에 같이 있었는데도... 숨 막히는 기분은 그대로였어."

    "어쩌면 내일은 괜찮아질지도 모른다고, 스스로를 다독이려던 참이었다."
    
    play sound "audio/cellphone.mp3"
    "징."
    stop sound
    "책상 위에 둔 휴대폰이 짧게 울렸다."
    "화면을 켜보니, 평소엔 알림을 꺼두고 신경도 안 쓰던," 
    "'6학년 3반 단톡방'에 새 메시지가 쌓이고 있었다."

    n "뭐지...?"

    "무심코 단톡방을 열었다."

    $ quick_menu = False
    call screen class_chat
    $ quick_menu = True

    if f_r2_chat_checked:
        $ note_chat = True
        "처음엔 장난처럼 보였다."
        "가볍게 던진 말 몇 개, 웃음 표시 몇 개, 아무렇지도 않게 이어지는 태그."
        "그런데 화면을 위로 더 올릴수록 숨이 천천히 막혀 왔다."

        "낮에 운동장에서 느꼈던 이상한 공기가, 이제는 문장으로 그대로 남아 있었다."
        "하린이를 부르는 말투, 대답이 없다고 몰아붙이는 말들, 웃기다는 듯 덧붙는 반응."
        "교실에서는 따로따로 보여서 애매했던 것들이, 단톡방에서는 한눈에 보였다."

        n "..."
        n "이건 그냥 분위기가 이상한 정도가 아니야."
        n "하린이는 계속 이런 말들을 보고 있었던 거야."

        "내가 오늘 본 것들이 우연이 아니었다는 게, 화면 안에 너무 선명하게 남아 있었다."

    else:
        "몇 줄 읽지 않았는데도 심장이 불편하게 내려앉았다."
        "더 보면 안 될 것 같은데, 그만 봐도 안 될 것 같았다."
        n "기분이 너무 이상해..."
        n "근데... 이걸 그냥 닫아버리면 또 아무것도 못 하게 되는 거 아냐?"

    menu:
        "소윤이에게 개인톡을 보낸다.":
            $ f_r2_chat_with_soyoon = True
            $ trust_soyun += 1

            "한참 화면만 내려다보다가, 결국 메시지 앱을 열었다."
            "대화 목록 속 소윤의 프로필이 눈에 들어왔다."

            $ quick_menu = False
            call screen messenger_contact_select
            $ quick_menu = True

            if _return == "soyun":
                $ quick_menu = False
                call screen soyoon_dm_chat
                $ quick_menu = True

            "답장은 짧았지만, 화면 너머의 망설임이 그대로 전해지는 것 같았다."
            "지난번 화장실 앞에서 마주쳤던 소윤이 표정이 겹쳐 떠올랐다."
            "휴대폰 화면 속 글자가 서서히 어제의 장면으로 바뀌는 것만 같았다."

            scene black with fade
            pause 1.0

            scene bg_13 with dissolve
            s "..."
            s "처음엔 다들 그러길래 나도 그냥 있었어."
            s "근데 어느 순간부터 너무 심해진 것 같더라고."
            s "그때 뭐라고 하려고 했는데... 이미 너무 늦은 것 같아서."
            s "지금 와서 내가 뭐라고 해봤자 아무것도 안 바뀔 것 같고..."

            scene black with dissolve
            "소윤이는 몰라서 가만히 있던 게 아니었다."
            "처음엔 별생각 없이 같이 웃고 넘겼다가, 어느 순간 이건 잘못됐다는 걸 알게 됐고,"
            "그때부터는 어떻게 멈춰야 할지 몰라 더 가만히 있었던 거다."

            scene bg_3 with fade
            n "(소윤이도 이게 잘못됐다는 건 알고 있어.)"
            n "(다만 타이밍을 놓쳐버렸다고 생각하는 거야.)"
            n "(내일 다시 제대로 봐야 해.)"
            n "(소윤이도, 하린이도. 이번엔 그냥 지나치면 안 돼.)"

        "휴대폰을 끄고 내일 직접 확인해 본다.":
            "휴대폰 화면이 꺼지자 방 안이 갑자기 더 어두워진 것 같았다."
            "이미 봐버린 이상, 어제처럼 모르는 척할 수는 없었다."

            n "(내일 다시 제대로 봐야 해.)"
            n "(소윤이도, 하린이도. 이번엔 그냥 지나치면 안 돼.)"

    jump r2_s4_bathroom


# ----------------------------------------------------------
# R2-S4. 2회차 다음 날 아침 — 화장실 앞 복도
# ----------------------------------------------------------
label r2_s4_bathroom:
    $ note_bathroom = True
    scene black with fade
    pause 0.8
    scene bg_4 with fade
    "다음 날 아침."
    "교실 문을 열 때 나도 모르게 숨을 크게 들이마셨다."
    "교실은 평소와 다름없이 시끄러웠다."
    "근데 이제는 안다. 이 평범한 소리 밑에 뭐가 깔려 있는지."

    "나는 자리에 가방을 던져 놓듯 올려두고, 쉬는 시간만 기다렸다."
    "칠판의 글씨는 눈에 들어오지 않았고, 선생님 목소리도 멀리서 들리는 것처럼 희미했다."
    "시계 초침 소리만 유난히 크게 들렸다."

    n "(쉬는 시간 종이 울리면, 바로 자리에서 일어나자.)"
    n "(이번에도,)" 
    n "(오늘이 하린이를 보는 마지막 날일 수 있으니까.)"
    play sound "audio/bell.mp3"
    "쉬는 시간 종이 치자마자, 나는 거의 튕겨 나가듯 자리에서 일어났다."

    stop sound fadeout 1.0
    scene bg_8 with fade
    "화장실 앞 복도 끝."
    "화장실 문이 열리더니 소윤이가 먼저 걸어 나왔다."
    
    scene bg_8_blur with dissolve
    show s6 at left_stage with dissolve
    "소윤이는 나를 보자 흠칫 놀란 듯 어깨를 움츠렸다."
    "무언가 들킨 사람처럼 시선을 피한 채 발걸음을 재촉했다."
    show h10 at right_stage with dissolve
    "그리고 그 뒤를 따라 하린이가 천천히 걸어 나왔다."
    hide s6 with dissolve
    show s8 at left_stage with dissolve
    "나는 이 장면을 알고 있다."
    "하린이의 부은 눈, 소윤이의 피하는 시선." 
    "전부... 저번과 같으니까."
 
    hide s8 
    hide h10 
    with dissolve
    scene bg_8 with dissolve

    "어제 밤, 단톡방에서 본 문장들이 머릿속을 스쳐 지나갔다."
    "내일부터 하린이는 이 학교에 오지 않을지도 모른다."
    "그 생각이 가슴을 꽉 누르는 것 같았다."
    scene bg_8_blur with dissolve
    show s3 at left_stage 
    show h5 at right_stage
    with dissolve    
    "붉어진 눈으로 바닥만 보는 하린이와, 서둘러 지나가려는 소윤이."
    "두 사람이 반대쪽으로 걸어가는 걸 보면서, 나는 입술을 꽉 깨물었다."

    menu:
        "서둘러 지나가려는 소윤이를 붙잡고 묻는다.":
            $ f_r2_bath_soyoon_talk = True
            hide s3
            hide h5
            with dissolve
            scene bg_8 with dissolve

            n "소윤아, 잠깐만."

            "내 옆을 지나치려는 소윤의 팔을 엉겁결에 붙잡았다."
            scene bg_8_blur with dissolve
            show s6 at center_stage with dissolve
            "소윤은 깜짝 놀라 나를 돌아봤다."

            if f_r2_chat_with_soyoon:
                n "어제 네가 한 말 계속 생각났어."
                n "무서운 거 알아. 근데 계속 이렇게 있으면 하린이만 더 버티기 힘들어져."
            else:
                n "나 어제 단톡방 봤어."
                n "운동장에서 본 것만이 아니더라."
                n "너도 알고 있었잖아."

            hide s6 with dissolve
            show s8 at center_stage with dissolve
            "당황하던 소윤이 얼굴이 금세 굳었다."
            "아니라고 하고 싶은 것 같았지만, 결국 아무 말도 하지 못했다."
            s "..."
            s "처음엔 그냥 다들 그러니까 나도 아무 생각 없이 있었어."

            hide s8 with dissolve
            show s3 at center_stage with dissolve
            s "근데 어느 순간부터 점점 심해지더라고."
            s "그걸 알게 된 순간엔, 이미 늦은 것 같아서..."
            hide s3 with dissolve

            scene bg_8 with dissolve
            "마지막 말은 거의 들리지 않을 만큼 작았다."
            "소윤이가 그걸 모르지 않았다는 건 이미 알고 있었다."
            "하지만 직접 듣고 나니, 그냥 넘어갈 수 없는 일이 더 분명해졌다."
            "이제는 소윤이도 모른 척만 할 수 없을 것 같았다."

            $ trust_soyun += 1

            scene black with dissolve
            "소윤이가 교실로 사라진 뒤, 나는 고개를 돌려 하린이가 걸어간 쪽을 바라봤다."
            "계단 아래로 사라진 뒷모습이 아직 눈에 남아 있었다."

        "혼자 걷고 있는 하린이에게 다가가 말을 건다.":
            $ trust_harin += 1
            $ key2_stay_with_harin = True
            $ f_r2_harin_connect = True

            scene bg_8 with dissolve
            n "하린아..."

            scene bg_8_blur with dissolve
            show h16 at center_stage with dissolve
            "조심스럽게 다가가 부르자, 하린이가 화들짝 놀라며 몸을 움찔했다."
            "하지만 이번엔 바로 도망치지 않았다."

            n "지금 당장 뭐라고 말 안 해도 돼."
            n "근데 너 혼자 두고 싶지 않아."

            hide h16 with dissolve
            show h10 at center_stage with dissolve
            h "왜 이제 와서 그래."

            "짧은 말이었는데, 그 안에 서운함이랑 포기랑 전부 섞여 있었다."
            "나는 바로 대답하지 못했다."

            n "..."
            n "이제라도 알게 됐으니까."
            n "그래서 이번엔 모른 척 안 하려고."

            hide h10 with dissolve
            show h5 at center_stage with dissolve
            "하린이의 눈빛이 아주 조금 흔들렸다."
            hide h5 with dissolve

        "둘을 그냥 보내지 않고, 두 사람 앞에서 같이 말한다.":
            $ f_r2_bath_soyoon_talk = True
            $ trust_soyun += 1
            $ trust_harin += 1
            $ key2_stay_with_harin = True
            $ f_r2_harin_connect = True

            n "둘 다 잠깐만."

            "소윤도, 하린도 동시에 멈춰 섰다."
            "목이 바짝 말랐지만 이번엔 물러서기 싫었다."

            n "나 어제 단톡방 봤어."
            n "운동장에서 느꼈던 게 착각이 아니었어."
            n "이제 못 본 척 안 할 거야."

            "하린의 얼굴이 굳었다."

            "소윤은 그대로 얼어붙은 채 내 눈치를 살폈다."

            n "지금 당장 다 말해야 한다는 뜻은 아니야."
            n "혼자 다 버텨야 한다는 뜻도 아니고."
            n "근데 아무도 아무 말도 안 하면, 저 애들만 더 당당해지는 거야."

            "잠깐의 정적."
            "복도 끝에서 떠드는 소리가 멀게 울렸다."

            s "...나도 알아."


            "하린은 아무 대답도 하지 않았다."
            hide h5 
            hide s3
            with dissolve
            scene bg_8 with dissolve
            "하지만 적어도, 두 사람 다 등을 돌리지는 않았다."
            "처음이었다."

    jump r2_s5_hallway_decision


# ----------------------------------------------------------
# R2-S5. 2회차 쉬는 시간 끝 — 같이 갈 사람을 정한다
# ----------------------------------------------------------
label r2_s5_hallway_decision:
    scene black with fade
    scene bg_7 with dissolve

    play sound "audio/bell.mp3"
    "예비종이 울렸다."
    "복도에 있던 애들이 하나둘 교실 쪽으로 움직이기 시작했다."

    stop sound fadeout 1.0

    if f_r2_bath_soyoon_talk:

        "소윤이도 고개를 숙인 채 교실 쪽으로 발을 돌리려 했다."
        "짧은 대화는 끝났지만, 이상하게도 이번엔 여기서 멈추면 안 될 것 같았다."
        "지금 돌아서면 또 아무 일도 없었던 것처럼 지나갈 것 같았다."
        "어제 본 단톡방, 운동장에서 본 장면들, 그리고 방금 들은 소윤이의 말."
        "이제는 내가 본 것들이 분명히 있었다."

        scene bg_7_blur with dissolve
        show s2 at center_stage with dissolve

        menu:
            "소윤에게 같이 교무실에 가자고 제안한다.":

                n "소윤아."
                n "나 혼자 말하면 또 얼버무려질 수도 있어."
                n "네가 본 걸... 같이 말해줄 수 있어?"

                if trust_soyun >= 2:
                    $ f_r2_soyoon_join = True
                    $ key3_move_with_soyoon = True

                    "소윤이는 겁먹은 얼굴로 교실 쪽을 돌아봤다."
                    "민재나 예서가 복도에라도 나타날까 봐 두려워하는 눈빛이었다."
                    "한참 망설이던 소윤이가, 끝내 아주 작게 고개를 끄덕였다."

                    hide s2 with dissolve
                    show s10 at center_stage with dissolve
                    s "응. 같이 갈게."
                    hide s10 with dissolve

                    jump r2_s6_report

                else:
                    "소윤이는 입술을 꾹 깨물고 한참 동안 아무 말도 하지 못했다."
                    "방금까지도 흔들리던 눈빛이, 이번에는 겁에 눌린 듯 아래로 떨어졌다."

                    hide s2 with dissolve
                    show s3 at center_stage with dissolve
                    s "미안해."
                    s "나… 아직은 못 하겠어."
                    s "내가 같이 말했다가, 예서랑 민재가 나까지 미워하면 어떡해."
                    hide s3 with dissolve

                    scene bg_7 with dissolve

                    n "(소윤이도 알고는 있어.)"
                    n "(하지만 아직 같이 말할 만큼 마음이 움직인 건 아니야.)"
                    n "(억지로 끌고 갈 수는 없어.)"

                    if note_chat or f_r2_harin_connect:
                        menu:
                            "증거가 부족해도, 혼자라도 선생님께 말씀드리러 간다.":
                                n "그래도 내가 본 것들은 사실이야."
                                n "소윤이가 같이 가지 못해도, 혼자서라도 말씀드려야 해."
                                jump r2_s6_report

                            "오늘은 무리다. 여기서 물러서자.":
                                "나는 결국 교무실 쪽으로 향하던 발을 멈췄다."
                                "머릿속으로는 가야 한다는 걸 알면서도, 몸이 움직이지 않았다."
                                jump loop3_intro
                    else:
                        n "(단톡방도 못 봤고, 하린이와도 제대로 연결되지 못했다.)"
                        n "(지금 교무실에 가 봤자 아무것도 제대로 말할 수가 없어.)"
                        "결국 발걸음이 교실 쪽으로 향했다."
                        jump loop3_intro


            "이번에는 내가 혼자 간다.":
                "말이 목 끝까지 올라왔지만, 더 이상 소윤을 붙잡을 수가 없었다."
                "억지로 끌고 가는 건 아닌 것 같았다."

                hide s2 with dissolve

                if note_chat or f_r2_harin_connect:
                    n "그래도 내가 본 것들은 사실이야. 혼자서라도 말씀드리자."
                    jump r2_s6_report
                else:
                    n "(하지만 지금 내 손에는 너무 적은 것밖에 없다.)"
                    n "(단톡방도, 하린이의 마음도, 같이 말해 줄 사람도 놓쳤다.)"
                    "나는 교무실 쪽으로 향하려던 발을 멈췄다."
                    jump loop3_intro

    else:
        "소윤이와는 제대로 이야기하지 못한 채 시간이 지나가 버렸다."
        "그래도 어제 본 단톡방과 운동장에서 본 장면들은 계속 마음에 걸렸다."
        "이대로 교실로 돌아가면 또 아무 일도 없었던 것처럼 지나갈 것 같았다."

        if note_chat or f_r2_harin_connect:
            menu:
                "증거가 부족해도, 혼자라도 선생님께 말씀드리러 간다.":
                    n "같이 말해 줄 사람은 없지만, 내가 본 것까지 사라지는 건 아니다."
                    n "이번엔 혼자라도 말씀드려야 한다."
                    jump r2_s6_report

                "오늘은 무리다. 여기서 물러서자.":
                    "나는 결국 교무실 쪽으로 향하던 발을 멈췄다."
                    "말해야 한다는 걸 알면서도, 입이 떨어지지 않았다."
                    jump loop3_intro
        else:
            n "(단톡방도 못 봤고, 소윤이도 설득하지 못했다.)"
            n "(지금 교무실에 가 봤자 아무것도 제대로 말할 수 없을지도 몰라.)"
            menu:
                "그래도 이상하다고 느낀 장면들을 선생님께 말씀드린다.":
                    n "(완벽한 증거는 없어도, 내가 이상하다고 느낀 건 사실이야.)"
                    n "(아무 말도 하지 않는 것보다는 낫다.)"
                    jump r2_s6_weak_to_loop3

                "오늘은 무리다. 여기서 물러서자.":
                    "결국 발걸음이 교실 쪽으로 향했다."
                    jump loop3_intro

label r2_s6_weak_to_loop3:

    scene black with fade
    pause 0.8

    scene bg_9 with fade
    "다음 날 아침."
    "교실은 겉보기에는 평소와 크게 달라지지 않았다."

    "선생님은 하린이 자리를 몇 번이나 바라보셨고,"
    "민재와 예서도 잠깐은 조용해진 것 같았다."

    "하지만 그뿐이었다."

    "내가 말한 건 너무 흐릿했고,"
    "누가 봐도 부정하기 어려운 증거도, 같이 말해 줄 사람도 충분하지 않았다."

    scene cg_1 with dissolve
    "하린의 빈자리는 그대로였다."

    n "(말하긴 했어.)"
    n "(하지만 제대로 말한 건 아니었어.)"
    n "(내가 본 장면들이 서로 이어져 있다는 걸, 더 분명하게 보여줬어야 했어.)"

    scene bg_3 with fade
    "그날 밤."
    "눈을 감았는데도 하린의 빈자리가 계속 떠올랐다."

    "이번엔 아무것도 하지 않은 건 아니었다."
    "그렇지만, 부족했다."

    scene black with blink_black
    scene bg_3 with blink_black
    scene black with blink_black
    scene bg_3 with blink_black_long

    scene black with Dissolve(1.0)
    pause 1.5

    jump loop3_intro


# ----------------------------------------------------------
# R2-S6. 2회차 교무실 보고 — 조건별 보고 장면
# ----------------------------------------------------------
label r2_s6_report:
    scene black with fade
    scene bg_10 with dissolve

    if f_r2_soyoon_join:
        "쉬는 시간이 끝나기 직전, 나와 소윤은 교무실 앞에 멈춰 섰다."
    else:
        "쉬는 시간이 끝나기 직전, 나는 혼자 교무실 앞에 멈춰 섰다."

    "문 하나를 사이에 두고도 심장이 시끄럽게 뛰었다."

    "저번의 기억이 스쳤다."
    "그때의 나는 쪽지 하나만 쥔 채,"
    "조각난 장면들을 제대로 설명하지도 못한 채 서 있었다."

    "하지만 이번엔 달랐다."

    if f_r2_soyoon_join and note_chat:
        "나는 운동장에서 하린이만 따로 떨어져 있던 장면을 봤다."
        "단톡방에는 하린이를 몰아붙이던 말들도 그대로 남아 있었다."
        "그리고 내 옆에는, 같이 봤다고 말해 줄 소윤이가 있었다."

    elif f_r2_soyoon_join:
        "나는 운동장에서 하린이만 따로 떨어져 있던 장면을 봤다."
        "그리고 내 옆에는, 그때 같이 이상하다고 느꼈던 소윤이가 있었다."

    elif note_chat:
        "나는 운동장에서 하린이만 따로 떨어져 있던 장면을 봤다."
        "단톡방에는 하린이를 몰아붙이던 말들도 그대로 남아 있었다."
        "혼자였지만, 이번엔 선생님께 보여 드릴 수 있는 게 있었다."

    elif f_r2_harin_connect:
        "나는 운동장에서 하린이만 따로 떨어져 있던 장면을 봤다."
        "그리고 하린이와 직접 이야기도 나눴다."
        "다 말할 수 있을지는 모르겠지만, 지난번처럼 아무것도 모르는 상태는 아니었다."

    else:
        "나는 운동장에서 하린이만 따로 떨어져 있던 장면을 봤다."
        "하지만 같이 말해 줄 친구도 없고, 선생님께 보여 드릴 단톡방 캡처도 없었다."

    call screen teacher_report

    if _return == "report_done":
        "나는 숨을 한 번 고르고 문을 열었다."
        "이번엔 물러서지 않기로 했다."
        jump r2_s6_teacher

    elif _return == "report_weak":
        "말은 꺼냈지만, 선생님께 보여 드릴 캡처는 없었다."
        "같이 봤다고 말해 줄 친구도 옆에 없었다."
        "그래도 그냥 모른 척하고 돌아갈 수는 없었다."

        scene bg_10_blur with dissolve
        show t6 at center_stage with dissolve
        t "그렇구나. 네가 왜 걱정하는지 알겠어."
        t "선생님이 쉬는 시간하고 점심시간에 더 잘 살펴볼게. 말해줘서 고마워."
        hide t6 with dissolve

        scene bg_10 with dissolve
        "내가 말한 것만으로 바로 달라질지는 알 수 없었다."
        "그래도 이제 선생님은 하린이를 더 지켜봐 주실 것이다."
        "그렇게 생각하니 조금은 안심이 됐다."
        jump r2_s6_weak_to_loop3

    else:
        "문고리를 잡았던 손이 결국 떨어졌다."
        "말해야 한다는 걸 알면서도, 몸이 움직이지 않았다."
        jump r2_s6_bad_rework

# ----------------------------------------------------------
# R2-S6-BAD. 2회차 실패 결말 — 문체 복구본
# ----------------------------------------------------------
label r2_s6_bad_rework:
    scene black with fade
    "결국 이번에도 말해야 할 순간에 멈춰 서고 말았다."
    "이상하다는 건 알았다."
    "잘못됐다는 것도 분명히 느꼈다."
    "그런데도 끝까지 제대로 말하지 못했다."

    scene bg_9 with fade
    "다음 날, 교실은 겉보기엔 평소와 다르지 않았다."
    "아이들은 떠들고, 웃고, 수업 준비를 했다."
    "하지만 하린이 자리는 비어 있었다."
    "그 빈자리가 아무렇지 않게 놓여 있는 게 더 이상하게 느껴졌다."

    "민재와 예서는 잠깐 조용해지는 듯했다."
    "하지만 시간이 조금 지나자 다시 예전처럼 웃고 떠들었다."
    "아무도 하린이 이야기를 꺼내지 않았다."
    "마치 원래부터 그 자리가 비어 있었던 것처럼."

    scene cg_1 with dissolve

    "그리고 이번엔 그게 더 또렷하게 보였다."
    "하린이가 힘들어했다는 걸 몰라서 못 움직인 게 아니었다."
    "알고도 제대로 움직이지 못한 거였다."

    scene black with dissolve
    n "..."
    n "이번엔 보였는데도."

    "그 말이 마음속에 오래 남았다."

    scene black with fade
    centered "{size=34}{color=#FFFFFF99}엔딩{/color}{/size}\n\n{size=54}{color=#E8736C}{b}후회 엔딩: 보았지만 멈추지 못한 날{/b}{/color}{/size}\n\n{size=28}{color=#FFE1DE}알고도 충분히 움직이지 못한 두 번째 기회{/color}{/size}"

    jump r2_retry_menu


# [수정 후: 디지털 증거 관련 변수 완전 초기화 추가]
label r2_retry_menu:
    "아직 놓친 장면들과 대화들이 있다. 이번엔 다른 선택을 해보자."
    menu:
        "2회차의 시작(월요일 아침)으로 돌아간다.":
            $ trust_soyun = 0
            $ trust_harin = 0
            $ trust_minjae = 0

            $ key1_structure = False
            $ key2_stay_with_harin = False
            $ key3_move_with_soyoon = False
            $ key4_minjae_pattern = False
            $ f_r2_chat_with_soyoon = False
            $ f_r2_bath_soyoon_talk = False
            $ f_r2_soyoon_join = False
            $ f_r2_harin_connect = False

            $ note_chat = False
            $ f_r2_chat_checked = False
            $ chat_scroll_depth = 0

            $ inv_pe_bottle = False
            $ inv_pe_bench = False
            $ talk_pe_harin = False
            $ talk_pe_minjae = False
            $ talk_pe_soyun = False

            jump loop2_start


# ==========================================================
# R2-S6. 2회차 결말 — 무너지는 벽과 남은 후회
# ==========================================================
label r2_s6_teacher:
    scene black with fade
    scene bg_10 with dissolve

    if f_r2_soyoon_join:
        "나와 소윤은 교무실 문을 열고 들어갔다."
    else:
        "나는 혼자 교무실 문을 열고 들어갔다."

    "문턱을 넘는 순간부터 목 안이 바짝 말랐다."
    

    scene bg_10_blur with dissolve
    show t4 at center_stage with dissolve

    t "응? 얘들아 무슨일이니?"

    if f_r2_soyoon_join and (note_chat or f_r2_chat_checked):
        "나는 단톡방에 남아 있던 메시지를 선생님께 보여드렸다."
        "소윤이도 옆에서 자신이 본 일을 조심스럽게 이야기했다."
        "이야기를 들을수록 선생님의 표정이 점점 굳어졌다."

    elif f_r2_soyoon_join:
        "나는 운동장에서 본 일을 선생님께 말씀드렸다."
        "소윤이도 자신이 이상하다고 느꼈던 순간들을 조심스럽게 덧붙였다."
        "선생님은 심각한 표정으로 우리 이야기를 끝까지 들으셨다."

    elif note_chat or f_r2_chat_checked:
        "나는 단톡방에 남아 있던 메시지를 선생님께 보여드렸다."
        "화면을 확인하던 선생님의 표정이 천천히 굳어졌다."

    elif f_r2_harin_connect:
        "나는 체육 시간에 있었던 일과 하린이가 불안해 보였던 모습을 차근차근 설명했다."
        "선생님은 중간에 말을 끊지 않고 내 이야기를 끝까지 들어주셨다."

    else:
        "나는 내가 본 일을 기억나는 대로 설명했다."
        "정리해 둔 증거도, 함께 말해 줄 사람도 없어서 자꾸 말이 꼬였다."
        "그래도 선생님은 재촉하지 않고 내 이야기를 끝까지 들어주셨다."

    "이번엔 달랐다."
    "그냥 '분위기가 이상해요' 정도로 얼버무리는 게 아니었다."
    "선생님도 그걸 바로 알아차리신 것 같았다."
    "그냥 친구들끼리 장난친 걸로 넘기실 분위기가 아니었다."

    hide t4 with dissolve
    show t7 at center_stage with dissolve
    t "알겠어."
    t "네가 말해준 내용, 선생님이 그냥 넘기지 않을게."
    t "하린이 상태부터 먼저 확인하고, 필요한 조치를 차근차근 해볼게."


    hide t7 with dissolve
    scene bg_7 with dissolve
    "교무실을 나왔을 때 복도는 이상할 만큼 조용했다."
    "아이들은 거의 다 교실로 돌아간 시간이었다."
    "형광등 불빛만 희미하게 복도를 비추고 있었다."

    if f_r2_soyoon_join:

        "소윤이는 내 옆에서 아무 말도 하지 않았다."
        "나도 말이 없었다."
        "계단을 반쯤 내려갔을 때, 소윤이가 아주 낮게 말했다."

        scene bg_7_blur with dissolve
        show s3 at center_stage with dissolve
        s "나, 진작에 말했어야 했는데."
        hide s3 with dissolve

        scene bg_7 with dissolve
        "뭐라고 대답해야 할지 몰랐다."
        "맞는 말이기도 하고, 틀린 말이기도 했다."
        "누가 먼저 말했어야 했는지, 누가 더 잘못했는지는 지금 중요하지 않았다."

        n "..."
        n "그래도 지금 말했잖아."

        "내 말이 위로가 됐는지는 모르겠다."
        "소윤은 잠깐 입술을 깨물더니 고개만 작게 끄덕였다."

    else:

        "복도에는 나 혼자 서 있었다."
        "같이 말해 줄 사람은 없었다."
        "말을 꺼내는 내내 목소리가 떨렸고,"
        "몇 번이나 내가 너무 예민한 건 아닐까 하는 생각이 들었다."

        n "(그래도 말했어.)"
        n "(완벽하게 말하진 못했지만, 이번엔 그냥 삼키지 않았어.)"

        "이상하게 다리가 무거웠다."
        "잘한 건지, 정말 이게 맞는지 아직 다 확신할 수는 없었다."

    scene black with dissolve
    "그래도 적어도 하나만은 분명했다."
    "이번엔 외면하지 않았다."

    scene bg_9 with fade

    "다음 날 아침."

    "교실 문이 열리자마자 예서와 민재가 차례로 불려 나갔다."

    "한참 뒤 돌아온 두 사람은 평소와 달랐다."

    "늘 당당하던 예서의 얼굴은 하얗게 질려 있었고,"
    "민재는 입을 댓발 내민 채 아무 말도 하지 않았다."

    n "쟤네가 강했던 게 아니야."
    n "우리가 아무 말도 하지 않았으니까 강해 보였던 것뿐이야."

    "그제야 교실의 분위기가 조금씩 달라지기 시작했다."

    scene cg_1 with dissolve

    "하지만 하린이는 오늘도 학교에 오지 않았다."

    "비어 있는 자리를 바라보자 가슴 한쪽이 서늘하게 식었다."

    scene black with dissolve

    "이제야 무언가 움직이기 시작했는데,"
    "하린이는 그 자리에 없었다."

    "그 사실이 오래도록 마음에 남았다."

    scene bg_3 with fade
    "그날 밤."
    "눈을 감고 누워 있는데도 교무실의 형광등 불빛,"

    if f_r2_soyoon_join:
        "떨리던 소윤이 목소리,"
    else:
        "내가 혼자 더듬거리며 말하던 목소리,"

    "하린의 비어 있는 자리가 계속 번갈아 떠올랐다."

    "겨우 늦지 않게 도착했다고 생각했는데,"
    "그래도 무언가를 놓친 것 같은 기분이 가시지 않았다."

    scene black with blink_black
    scene bg_3 with blink_black
    scene black with blink_black
    scene bg_3 with blink_black_long

    scene black with Dissolve(1.0)
    pause 1.5

    jump loop3_intro



############################################################
## 3회차 — 진정한 연대와 구조의 붕괴
############################################################
label loop3_intro:

    $ loop_no = 3
    $ trust_harin = 1 if key2_stay_with_harin else 0
    $ trust_soyun = 1 if key3_move_with_soyoon else 0

    # 2회차에서 민재의 패턴을 파악했다면,
    # 3회차에서도 그 정보를 유지한다.
    $ trust_minjae = 2 if key4_minjae_pattern else 0

    $ r3_morning_time = 2 
    $ r3_action_harin = False
    $ r3_action_soyun = False
    $ r3_action_minjae = False

    $ talk_pe_minjae = False
    $ talk_pe_soyun = False
    $ talk_pe_harin = False
    $ note_witness = False

    $ f_r3_soyoon_coop = False
    $ f_r3_stay_together = False
    $ f_r3_teacher_support = False

    # 핵심 수정:
    # 2회차에서 민재 패턴을 파악했으면,
    # 3회차 아침에 민재를 다시 부르지 않아도 히든 조건을 열어둔다.
    $ f_r3_minjae_weakness = True if key4_minjae_pattern else False

    scene black with fade
    "어둠 속에서 하린의 얼굴이 천천히 떠올랐다."

    scene cg_9 with dissolve
    "빨갛게 부은 눈가, 잔뜩 움츠러든 어깨." 
    "내가 끝내 구해내지 못한 하린이였다."

    play sound "audio/heartbeat.mp3"
    n "하린아."

    "내 부름에 하린이 천천히 등을 돌렸다."
    "점점 멀어지는 뒷모습을 향해 다급하게 손을 뻗었다."
    
    n "하린아, 이쪽이야. 내 목소리 안 들려? 제발 가지 마!"
    stop sound fadeout 1.0

    scene black with fade
    "하지만 내 목소리는 닿지 않았다."
    "아무리 팔을 뻗어도," 
    "하린이는 짙은 어둠 속으로 완전히 사라져버렸다."
    

    scene bg_4_blur at wake_blur
    with white_flash

    pause 0.3

    n "헉!"

    with blink_black

    "익숙한 소음, 의자 끌리는 소리, 발소리가 한꺼번에 밀려들었다."

    scene black with blink_black
    scene bg_4 at wake_clear
    with blink_black_long

    "황급히 땀에 젖은 손으로 휴대폰 화면을 켰다."

    "< 5월 10일 월요일 >"

    "세 번째였다."
    "다시 한번 시간이 되돌아갔다."
    "거친 숨을 고르며 자세를 바르게 고쳐 앉았다." 
    "지난 두 번을 차근차근 다시 떠올렸다."

    n "나는 계속 지켜보기만 하다가, 나중에 선생님께 말했어."
    n "그동안 하린이는 계속 혼자였던 거야."
    n "이번엔 저 애들한테 직접 하지 말라고 말할 거야."

    scene black with dissolve

    if key1_structure:
        n "(이번엔 지켜보기만 하지 않을거야.)"

    if key2_stay_with_harin:
        n "(하린이는 억지로 끌고 가는 것보다, 곁을 지켜줄 때 조금씩 반응했어.)"

    if key3_move_with_soyoon:
        n "(소윤이는 나쁜 애가 아니야. 제대로 말을 걸면 흔들릴 수 있어.)"

    if key4_minjae_pattern:
        n "(민재는 생각보다 단단하지 않아. 정면으로 찔리면 흔들려.)"

    n "나 혼자 선생님께 말하는 것만으로는 부족해."
    n "소윤이가 겁먹지 않고 자기가 본 일을 말할 수 있게, 내가 옆에서 함께해야 해."
    n "그리고 가장 중요한 건..."

    "조금 전 꿈속에서 끝내 손이 닿지 않았던 하린이의 뒷모습이 떠올랐다."

    n "내가 답을 정해 놓고 억지로 끌고 가면 안 돼." 
    n "하린이가 자기 마음을 말할 수 있을 때까지 기다리면서," 
    n "곁에 있어 줘야 해."
    n "이번에는 절대 하린이를 혼자 두지 않을 거야."

    jump r3_s1_morning
# ==========================================================
# R3-S1. 3회차 월요일 아침 — 달라진 시선
# ==========================================================
label r3_s1_morning:
    scene bg_4 with fade

    "익숙한 교실 풍경이 눈앞에 펼쳐졌다."
    "겉으로 보기엔 평소와 다를 것 없는 월요일 아침이었다."

    "하지만 이번엔 보였다."
    "누가 중심에 서 있고, 누가 바깥으로 밀려나 있는지도."

    "하린이는 책상에 조용히 앉아 혼자 공책만 내려다보고 있었다."
    "민재와 예서 쪽은 아침부터 시끄럽게 웃음소리를 터뜨리고 있었다."

    n "(이번엔 달라.)"
    n "(오늘 아침엔 관찰만 하지 않고,)" 
    n "(직접 말을 걸어볼 거야.)"
    jump r3_morning_choice


label r3_morning_choice:
    $ remaining_choices = (0 if r3_action_minjae else 1) + \
                          (0 if r3_action_soyun else 1) + \
                          (0 if r3_action_harin else 1)

    if r3_morning_time <= 0 or remaining_choices == 0:
        "예비령이 울린다. 이제 각자의 자리로 돌아가야 할 시간이다."
        jump r3_s2_class_start

    $ r3_choice_hint = "누구를 불러낼까? (남은 기회: %d번)" % r3_morning_time
    show screen choice_hint(r3_choice_hint)

    menu:
        "민재를 불러낸다." if not r3_action_minjae:
            hide screen choice_hint
            jump r3_morning_minjae_1on1

        "소윤이를 복도로 불러낸다." if not r3_action_soyun:
            hide screen choice_hint
            jump r3_morning_soyoon_1on1

        "하린이에게 조용히 다가간다." if not r3_action_harin:
            hide screen choice_hint
            jump r3_morning_harin_1on1
# ----------------------------------------------------------
# [1] 소윤 — 방관의 관성과 잃어버린 타이밍
# ----------------------------------------------------------
label r3_morning_soyoon_1on1:
    $ r3_action_soyun = True
    $ r3_morning_time -= 1

    scene bg_7 with fade

    "나는 예서 옆에 서 있던 소윤이에게 다가갔다."

    if key3_move_with_soyoon:
        "그리고는 소윤이만 들을 수 있게, 잠깐 복도에서 이야기하자고 조용히 말했다."
        "소윤이는 예서 쪽을 한 번 힐끗 보더니, 말없이 나를 따라 나왔다."
        $ trust_soyun += 1

    else:
        "나는 소윤이에게 잠깐 할 이야기가 있으니 복도로 나와 달라고 말했다."
        "소윤이는 예서의 눈치를 보다가, 마지못해 나를 따라 나왔다."


    scene bg_7_blur with fade
    show s6 at center_stage with dissolve

    s "왜? 무슨 일인데 그래?"

    n "하린이 얘기 좀 하려고."
    n "나도 처음에는 애들이 그냥 장난치는 줄 알았어."
    n "그런데 계속 지켜보니까, 장난이라고 넘기기에는 좀 심한 것 같더라."

    hide s6 with dissolve

    "하린이의 이름이 나오자 소윤이의 표정이 잠시 굳었다."
    "어떻게 말해야 소윤이도 솔직한 마음을 이야기할까?"

    menu:
        "너도 보면서 뭔가 이상하다고 느낀 적 있지 않아?":
            $ trust_soyun += 2

            "소윤이의 눈동자가 잠시 흔들렸다."

            n "너를 탓하려고 부른 건 아니야."
            n "너도 나처럼 뭔가 이상하다고 느꼈는지 궁금했어."

            show s3 at center_stage with dissolve

            s "…나도 좀 심하다고 생각한 적은 있어."
            s "그런데 내가 괜히 나섰다가 애들이 나까지 싫어하면 어떡해?"

            n "나도 그게 무서워서 계속 보고만 있었어."
            n "그래도 우리 둘이 같이 선생님께 말하면,"
            n "혼자 나서는 것보다는 덜 무서울 것 같아."

            "소윤이는 한동안 복도 바닥만 내려다보았다."
            "그러다 작게 숨을 내쉬고 나를 바라보았다."

            s "…알겠어. 나도 내가 본 건 솔직하게 말할게."
            s "대신 네가 옆에 같이 있어 줘."

            hide s3 with dissolve
            scene bg_7 with dissolve

            $ f_r3_soyoon_coop = True
            "소윤이가 나와 함께 선생님께 이야기하기로 했다."


        "너도 계속 보고만 있었으면서 아무 잘못 없는 척하지 마.":
            $ trust_soyun -= 1

            show s10 at center_stage with dissolve

            "소윤이의 표정이 순식간에 굳었다."

            s "내가 뭘 했다고 그래? 난 진짜 아무것도 안 했어."

            n "그러니까 문제라는 거야."
            n "하린이가 힘들어하는데도 계속 모르는 척했잖아."

            s "너는 말 진짜 쉽게 한다."
            s "나라고 마음이 편한 줄 알아?"
            s "나도 어쩌다 보니 나설 때를 놓친 거야."
            s "이제 와서 나한테만 잘못했다고 하면 어떡해?"

            hide s10 with dissolve
            scene bg_7 with dissolve

            "소윤이는 더 듣고 싶지 않다는 듯 교실로 들어가 버렸다."
            "잘못을 따지는 말에 소윤이는 결국 마음을 닫아 버렸다."

            $ f_r3_soyoon_coop = False

    jump r3_morning_choice


# ----------------------------------------------------------
# [2] 민재 — 주동자의 당혹감
# ----------------------------------------------------------
label r3_morning_minjae_1on1:
    $ r3_action_minjae = True
    $ r3_morning_time -= 1

    scene bg_7 with fade

    "오른쪽 뒤 창가 쪽에서 떠들던 민재를 불렀다."
    "민재는 처음엔 어리둥절한 얼굴을 하더니," 
    "내가 진지한 표정인 걸 보고 마지못해 복도로 따라 나왔다."

    n "민재야, 물어보고 싶은 게 있어서."
    n "너 혹시 하린이한테 뭐 마음에 안 드는 거라도 있어?"

    if key4_minjae_pattern:
        "민재는 평소처럼 '어쩌라고'식의 대답을 하려다 멈칫했다."
        "어쩐지 전보다 내 눈치를 보는 듯했다."

        scene bg_7_blur with dissolve
        show m4 at center_stage with dissolve
        m "아, 뭐... 딱히 마음에 안 드는 건 아니고. 그냥..."

        "민재는 우물쭈물하며 시선을 피했다."

        n "장난이라기엔 네 행동, 너무 치사해 보이는데."
        n "너도 네가 지금 비겁하게 굴고 있다는 거 알고 있지?"

        hide m4 with dissolve
        show m7 at center_stage with dissolve
        m "…아, 알았어. 안 하면 될 거 아냐. 왜 자꾸 시비야."
        hide m7 with dissolve
        scene bg_7 with dissolve

        "민재의 목소리가 한풀 꺾였다."

        $ trust_minjae += 2
        $ f_r3_minjae_weakness = True

    else:
        scene bg_7_blur with dissolve
        show m1 at center_stage with dissolve
        m "어쩌라고? 갑자기 뭔 소리야."
        hide m1 with dissolve
        scene bg_7 with dissolve
        "민재는 어이없다는 듯 콧방귀를 뀌며 비웃었다."
        "민재는 끝내 내 말을 흘려들었다."

        $ trust_minjae -= 1

    jump r3_morning_choice

# ----------------------------------------------------------
# [3] 하린 — 조용한 신뢰 확보 혹은 성급한 실수
# ----------------------------------------------------------
# [코딩 규칙 요약]
#   - 캐릭터 대사 직전: blur 배경 + show 캐릭터
#   - 내레이션/n 독백: 일반(선명) 배경
#   - 장소 이동: scene ○○ with fade
#   - 같은 장소 내 전환: scene ○○ with dissolve
#   - 날짜 전환: scene black with fade → pause 0.8
#   - 이미지 이름: h1~h15 (언더스코어 없음)
#   - 위치: center_stage / left_stage / right_stage
# ----------------------------------------------------------

label r3_morning_harin_1on1:
    $ r3_action_harin = True
    $ r3_morning_time -= 1

    scene bg_4 with dissolve

    if key2_stay_with_harin:
        "교실 가운데 앞쪽, 혼자 앉아 있던 하린은 전처럼 완전히 벽을 치지는 않았다."
        "내가 조용히 다가가자 아주 미세하게 시선을 들었다."
        $ trust_harin += 1
    elif f_r2_harin_connect:
        "하린은 여전히 경계하고 있었지만, 완전히 낯선 사람을 보듯 하지는 않았다."

    "나는 엎드려 있는 하린이의 곁에 조용히 앉아 아주 낮은 목소리로 속삭였다."
    n "하린아, 잠깐 나 좀 볼래?"

    scene bg_4_blur with dissolve
    show h10 at center_stage with dissolve
    "하린이가 천천히 고개를 들었다."
    "눈가가 발갛게 부어 있는 게 보였다."
    "주머니에 아침에 챙겨 넣은 사탕이 손에 잡혔다."

    menu:
        "사탕을 건네며 조용히 곁을 지킨다.":
            "하린의 눈이 살짝 커졌다."

            n "이거 내가 좋아하는 사탕인데, 너도 한번 먹어봐."

            "하린은 의심 가득한 눈으로 사탕을 보더니, 이내 조심스럽게 손을 뻗었다."

            hide h10 with dissolve
            show h16 at center_stage with dissolve
            h "…어, 고마워."

            n "하린아. 혹시 오늘 내가 네 옆에 계속 있어도 될까?"
            n "힘들면 언제든 말해줘."

            "하린이는 대답 대신 사탕을 꼭 쥐었다."
            "하린의 눈가가 조금 더 붉어진 것 같았다."

            hide h16 with dissolve

            $ trust_harin += 3
            scene bg_4 with dissolve
            "하린이가 처음으로 나를 조금 믿어 준 것 같았다."

        "하린아 솔직히 말해봐. 지금 괴롭힘 당하고 있는거지?":
            "내 말에 하린이의 눈동자가 순식간에 당황한 기색으로 물들었다."
            "하린이는 내 눈을 피했다."

            hide h10 with dissolve
            show h4 at center_stage with dissolve
            h "…아니야. 아무 일도 없어."
            hide h4 with dissolve

            scene bg_4 with dissolve
            "주변 아이들의 시선이 우리 쪽으로 쏠리자 하린이는 더 몸을 웅크렸다."

            n "(아차, 내가 너무 앞서 나갔나?)"
            n "(하린이는 지금 누군가 대신 싸워주는 걸 원치 않아.)"

            $ trust_harin -= 1
            "도와주려던 마음이 오히려 하린이를 더 움츠러들게 만들어버렸다."

    jump r3_morning_choice


# ----------------------------------------------------------
# 3단계: 국어 시간 시작 라벨
# ----------------------------------------------------------
label r3_s2_class_start:
    scene black with fade
    pause 0.8

    scene bg_11 with fade
    "1교시 국어 시간. 선생님이 칠판에 '역사 인물 분석 발표'라는 글자를 적으셨다."

    scene bg_11_blur with dissolve
    show t9 at center_stage with dissolve
    t "자, 지난번 모둠대로 모여서 역할 정해라. 다들 협력하고."
    hide t9 with dissolve

    scene bg_11 with dissolve
    "의자 끄는 소리와 함께 아이들이 모여 앉았다."
    "나는 내 모둠에 앉았지만, 온 신경은 대각선 앞쪽, 하린이네 모둠에 집중되어 있었다."
    "민재는 평소처럼 중심에 앉아 입을 열었다."

    scene bg_11_blur with dissolve
    show m2 at left_stage with dissolve
    m "야, 지난번에 말한 대로 예서가 발표하고 하린이가 자료..."

    # ----------------------------------------------------------
    # [분기 시작] 소윤의 협력 여부에 따른 반응
    # ----------------------------------------------------------
    if f_r3_soyoon_coop:
        # [루트 1] 소윤이 먼저 나서는 경우
        "민재의 말이 끝나기도 전에 소윤이가 조심스럽게, 하지만 분명하게 말을 끊었다."

        show s2 at right_stage with dissolve
        s "민재야, 잠깐만. 우리 역할 정할 때 하린이 의견도 좀 물어봐야 하지 않을까?"
        $ trust_harin += 2
        $ trust_soyun += 1

        "모둠이 갑자기 조용해졌다."
        "예서가 눈을 동그랗게 떴다."

        hide m2 with dissolve
        show m4 at left_stage with dissolve
        m "어? 아… 뭐, 물어보면 좋긴 한데. 하린이는 자료 조사가 편하다고 하지 않았나?"
        hide m4
        hide s2
        with dissolve

        scene bg_11 with dissolve
        "당황한 민재가 말을 더듬었다."
        jump r3_s2_harin_voice_check

    else:
        # [루트 2] 소윤의 침묵과 지원의 선택
        "민재는 거침없이 말을 이어갔다."

        hide m2 with dissolve
        show m3 at left_stage 
        show s3 at right_stage
        with dissolve
        m "하린이가 자료 조사하고 소윤이는 정리해서 메일로 보내. 그게 제일 빠르겠지?"
        
        hide m3 
        hide s3
        with dissolve

        scene bg_11 with dissolve
        "소윤이는 입술을 깨물며 창밖을 보거나 애매하게 고개를 끄덕였다."
        "아침에 내가 했던 경고가 머릿속을 맴도는 듯했지만, 결국 침묵하기로 선택한 것 같다."

        n "(소윤이는 아직 움직이지 않아. 결국 이번에도 내가 먼저 개입해야 하는 걸까?)"

        menu:
            "직접 끼어들어 하린의 역할을 제안한다.":
                jump r3_s2_player_intervene

            "일단 하린의 반응을 지켜본다.":
                n "지금 내가 나서면 하린이가 더 위축될지도 몰라. 일단은 지켜보자."
                jump r3_s2_harin_voice_check


# ----------------------------------------------------------
# [독립 장면] 지원의 직접 개입 (민재와의 대립)
# ----------------------------------------------------------
label r3_s2_player_intervene:
    $ trust_harin += 2
    $ trust_soyun += 1

    n "민재야, 역할 분담 너무 한쪽으로 쏠린 거 아냐? 하린이 의견도 들어보자."

    scene bg_11 with dissolve
    "내 목소리가 정적을 깨고 울려 퍼지자, 소윤의 어깨가 눈에 띄게 움찔했다."
    "소윤이가 나를 쳐다봤다."
    "자기가 못 한 말을 내가 대신 해버린 게 미안한 것 같기도,"
    "조금 부러운 것 같기도 한 눈이었다."


    if key4_minjae_pattern:
        "민재가 짜증스럽게 나를 노려보려다, 나와 눈이 마주치자 아침의 기억이 떠오른 듯 급격히 기가 죽었다."

        scene bg_11_blur with dissolve
        show m4 at center_stage with dissolve
        m "아... 뭐, 쏠린 건 아닌데. 그냥 하린이가 말을 안 하니까..."
        hide m4 with dissolve

        scene bg_11 with dissolve
        "민재는 바지춤에 손을 쓱쓱 문지르며 내 시선을 피했다. 이제 민재는 내 앞에서는 함부로 굴지 못한다."
        "교실의 공기가 순식간에 조용해졌고, 다른 아이들도 우리 모둠의 눈치를 보기 시작했다."
    else:
        scene bg_11_blur with dissolve
        show m10 at center_stage with dissolve
        m "야, 넌 너네 모둠이나 신경 써. 하린이도 이게 편하댔어. 그치, 하린아?"
        hide m10 with dissolve

        scene bg_11 with dissolve
        "민재는 보란 듯이 하린을 압박했다."

    "고개를 숙이고 있던 하린이가 천천히 고개를 들어 나를 쳐다보았다."
    jump r3_s2_harin_voice_check


label r3_s2_harin_voice_check:
    if trust_harin >= 5 or (key2_stay_with_harin and trust_harin >= 4):
        # ----------------------------------------------------------
        # [결과 1 & 2] 하린이가 용기를 내는 경우
        # ----------------------------------------------------------
        scene bg_11_blur with dissolve
        show h25 at center_stage with dissolve
        h "저… 나, 자료 정리 말고 대본 같이 짜고 싶어. 인물 분석하는 거 좋아해."
        hide h25 with dissolve

        if f_r3_soyoon_coop:
            # [경우의 수 1] 소윤 협조 O + 하린 용기 O (베스트: 완벽한 연대)
            scene bg_11_blur with dissolve
            show s9 at right_stage with dissolve
            s "그래? 그럼 나랑 같이 대본 보자! 나도 그게 더 좋을 것 같아."
            hide s9 with dissolve

            if key4_minjae_pattern:
                "소윤의 맞장구에, 민재는 입을 꾹 다물었다."

                scene bg_11_blur with dissolve
                show m7 at left_stage with dissolve
                m "…알았어. 마음대로 해라."
                hide m7 with dissolve

                scene bg_11 with dissolve
                "민재는 더 이상 아무 말도 하지 못했다. 뭔가 단단하게 굳어 있던 게 조금 흔들린 순간이었다."
            else:
                "소윤의 맞장구에 민재는 어이없다는 듯 인상을 팍 썼다."

                scene bg_11_blur with dissolve
                show m10 at left_stage with dissolve
                m "아씨, 그래 알았어. 니들끼리 다 해라."
                hide m10 with dissolve

                scene bg_11 with dissolve
                "투덜거리긴 했지만, 두 사람의 협동 앞에 민재는 더 이상 아무 말도 하지 못했다."

        else:
            # [경우의 수 2] 소윤 협조 X + 하린 용기 O (하린의 홀로서기 시작)
            if key4_minjae_pattern:
                "민재는 짜증을 내려다 말고 내 눈치를 살피더니, 마지못해 고개를 끄덕였다."

                scene bg_11_blur with dissolve
                show m4 at left_stage with dissolve
                m "…어, 그래? 뭐… 네가 정 하고 싶으면 그렇게 하든가."
                hide m4 with dissolve

                scene bg_11 with dissolve
                "나는 하린을 향해 싱긋 미소를 지어보였다. 늘 기운 없던 하린의 눈이 순간 반짝인 듯했다."
            else:
                "민재가 황당하다는 듯 하린을 쳐다보며 비꼬았다."

                scene bg_11_blur with dissolve
                show m7 at left_stage with dissolve
                m "네가 대본을? 흐름 끊기는 거 아냐? …뭐, 정 하고 싶으면 하든가."
                hide m7 with dissolve

                scene bg_11 with dissolve
                "민재는 불쾌한 티를 팍팍 냈지만, 하린의 단호함에 결국 한 발 물러섰다."
                "늘 기운 없던 하린의 눈이 순간 반짝인 듯했다."

    else:
        # ----------------------------------------------------------
        # [결과 3 & 4] 하린이가 여전히 위축된 경우
        # ----------------------------------------------------------
        scene bg_11_blur with dissolve
        show h23 at center_stage with dissolve
        h "…아니야. 나 그냥 민재가 시키는 거 할게. 그게 편해."
        hide h23 with dissolve

        if f_r3_soyoon_coop:
            # [경우의 수 3] 소윤 협조 O + 하린 위축 (안타까운 실패)
            scene bg_11 with dissolve
            "소윤이 안타까운 표정으로 하린을 바라봤지만, 당사자가 거부하자 더 나설 수 없었다."

            if key4_minjae_pattern:
                "민재는 어쩐지 내 시선을 피하며 머쓱하게 덧붙였다."

                scene bg_11_blur with dissolve
                show m1 at left_stage with dissolve
                m "야, 쟤가 편하다잖아. 난 그냥 쟤 편하라고..."
                hide m1 with dissolve

                scene bg_11 with dissolve
                "민재는 무어라 궁시렁거렸다. 나는 하린에게 안타까운 눈빛을 보냈다."
            else:
                "민재가 승리감에 찬 미소를 지었다."

                scene bg_11_blur with dissolve
                show m7 at left_stage with dissolve
                m "거봐, 얘 원래 이거 좋아한다니까. 괜히 오버 좀 하지 마."
                hide m7 with dissolve

                scene bg_11 with dissolve
                n "(아침에 하린이의 마음을 더 세심하게 돌봤어야 했다.)"

        else:
            # [경우의 수 4] 소윤 협조 X + 하린 위축 (최악: 2회차의 반복)
            if key4_minjae_pattern:
                "민재는 내 눈치를 힐끗 보더니 서둘러 상황을 정리했다."

                scene bg_11_blur with dissolve
                show m7 at left_stage with dissolve
                m "…그럼 정해진 거다? 딴소리하지 마라."
                hide m7 with dissolve

                scene bg_11 with dissolve
                "민재가 어쩐지 누그러졌지만 결과는 바뀌지 않았다. 결국 아무것도 바꾸지 못한 채 모둠 활동이 끝났다."
            else:
                scene bg_11_blur with dissolve
                show m7 at left_stage with dissolve
                m "거봐, 얘 원래 이거 좋아한다니까. 그럼 정해진 거다?"
                hide m7 with dissolve

                scene bg_11 with dissolve
                "교실의 공기는 여전히 차가웠다. 결국 아무것도 바꾸지 못한 채 모둠 활동이 끝났다."

    jump r3_s3_lunch


# ----------------------------------------------------------
# R3-S3. 3회차 점심시간 — 균열의 시작
# ----------------------------------------------------------
label r3_s3_lunch:
    scene black with fade
    pause 0.8

    play sound "audio/bell.mp3"
    scene bg_5 with fade
    "4교시 종료 종이 울렸다. 급식실은 언제나처럼 소란스럽다."

    stop sound fadeout 1.0

    "배식을 받고 돌아선 나는 6인용 테이블 쪽을 먼저 확인했다."
    scene bg_6 with dissolve
    "민재, 예서, 준호, 그리고 소윤이가 이미 자리를 잡고 앉아 있었다."
    "예서 옆의 빈 의자 위에는 저번과 똑같이 겉옷이 놓여 있었다."

    scene bg_5_blur with dissolve
    show h3 at center_stage with dissolve
    "잠시 후, 식판을 든 하린이가 그 테이블 앞을 지나갔다."
    "하린이는 겉옷이 놓인 자리를 지나쳐, 가장 구석진 자리로 향했다."
    hide h3 with dissolve

    scene bg_5 with dissolve
    "나는 식판을 고쳐 들고 하린이가 있는 구석 자리로 걸음을 옮겼다."

    # ----------------------------------------------------------
    # 1. 하린의 초기 반응
    # ----------------------------------------------------------
    if trust_harin >= 5:
        scene bg_6_blur with dissolve
        show h16 at center_stage with dissolve
        "다가오는 발소리에 고개를 든 하린이가 나를 발견했다."
        "하린이는 조심스럽게 맞은편 빈 의자를 쳐다보며 작게 고개를 끄덕였다."
        hide h16 with dissolve
        scene bg_6 with dissolve
        "나는 하린의 맞은편에 식판을 내려놓았다."
    else:
        scene bg_6_blur with dissolve
        show h5 at center_stage with dissolve
        "내가 맞은편에 다가가자, 하린이는 어깨를 움츠렸다."
        "벽을 바라본 채 빠르게 밥을 넘기는 모습은 저번과 같았다."
        hide h5 with dissolve
        scene bg_6 with dissolve
        n "천천히 먹어. 체하겠다."
        n "(하린이는 여전히 주변의 시선을 의식하고 있다.)"

    "하린과 마주 앉아 막 숟가락을 들었을 때였다."

    # ----------------------------------------------------------
    # 2. 소윤의 행동 (협력 여부에 따른 분기)
    # ----------------------------------------------------------
    if f_r3_soyoon_coop:
        # [변화 발생] 기존 자리에서의 이탈
        "저만치 떨어져 있는 6인용 테이블 쪽에서 요란하게 의자 끌리는 소리가 났다."
        "소윤이가 자신의 식판을 들고 자리에서 일어서 있었다."
        "그 모습을 본 예서가 미간을 찌푸렸다."

        scene bg_6_blur with dissolve
        show y9 at center_stage with dissolve
        y "야, 이소윤. 밥 먹다 말고 뭐 해?"
        hide y9 with dissolve

        show s11 at center_stage with dissolve
        s "…나 저쪽 가서 먹을게."
        hide s11 with dissolve

        scene bg_6 with dissolve
        "소윤은 테이블을 빠져나와, 우리 쪽으로 걸어왔다."
        "덜그럭. 소윤이 내 옆자리에 식판을 내려놓았다."

        scene bg_6_blur with dissolve
        show s9 at center_stage with dissolve
        s "자리 있지? 같이 먹자."
        hide s9 with dissolve

        scene bg_6 with dissolve
        "하린이는 눈을 크게 떴고, 멀리서 예서는 어이없다는 듯한 표정을 지었다."

        # 3. 민재의 반응
        if key4_minjae_pattern:
            "민재는 무언가 말을 꺼내려다, 이쪽을 보고 있는 나와 눈이 마주치자 조용히 고개를 돌렸다."
        else:
            "민재가 우리 쪽을 노려보며 목소리를 높였다."

            scene bg_6_blur with dissolve
            show m7 at center_stage with dissolve
            m "갑자기 왜 저래..."
            hide m7 with dissolve

            scene bg_6 with dissolve
            "민재는 불만을 표출했지만, 세 명이 앉은 우리 테이블로 다가오지는 않았다."

        if trust_harin >= 5:
            "하린의 어깨에서 뻣뻣한 힘이 천천히 빠지는 게 보였다. 셋이 함께하는 식사는 생각보다 고요했다."
        else:
            "소윤이 합류했지만, 하린은 여전히 소윤의 시선을 피하며 밥을 제대로 삼키지 못했다."

    else:
        # [상태 유지]
        "나는 슬쩍 6인용 테이블 쪽을 살폈다."
        "소윤이는 6인용 테이블에 가만히 앉아 있었다."

        "소윤은 저번처럼 밥을 깨작거리며 이쪽을 훔쳐보았다. 표정이 어두웠지만, 끝내 자리에서 일어나지는 않았다."
        "아무래도, 소윤은 익숙한 자리에 남는 것을 선택한 것 같다."

        if trust_harin >= 5:
            "하린이가 슬쩍 예서네 테이블을 보더니, 내 눈치를 보며 작게 속삭였다."

            scene bg_6_blur with dissolve
            show h25 at center_stage with dissolve
            h "…오늘도 같이 밥 먹어줘서 고마워."
            hide h25 with dissolve

            scene bg_6 with dissolve
            n "뭐가 고마워. 너랑 같이 밥 먹으니까 좋다."
            "나와 하린은 서로를 마주 보며 싱긋 웃었다."

        else:
            "저 멀리서 들려오는 아이들의 웃음소리에 하린이는 결국 밥을 다 먹지 못하고 숟가락을 내려놓았다."
            n "하린아 괜찮아?"

            scene bg_6_blur with dissolve
            show h16 at center_stage with dissolve
            h "응... 그냥 속이 좀 안 좋네."
            hide h16 with dissolve
            scene bg_6 with dissolve

            "나는 하린을 걱정스럽게 바라봤다."

    scene bg_5 with dissolve
    "빈 식판들이 퇴식구로 하나둘 사라졌다."
    "점심시간 끝을 알리는 종이 울리자, 시끌벅적하던 급식실도 조금씩 조용해졌다."

    scene bg_7 with dissolve
    "교실로 돌아가는 복도."
    "하린이의 걸음이 아침보다 조금 가벼워 보였다."
    "그래도 복도를 걷는 아이들 사이에는 여전히 이상한 기운이 남아 있었다."
    "하린이는 아직, 말이 많지 않았다."
    "그래도 오늘은 나와 눈이 마주쳤을 때 바로 시선을 피하지 않았다."
    "그게 생각보다 큰 변화처럼 느껴졌다."
    n "(이번 체육 시간, 하린이가 또 혼자 서 있는 꼴은 보지 않을 거야.)"
    jump r3_s4_pe


# ----------------------------------------------------------
# R3-S4. 3회차 체육 시간 — 균열의 증명
# ----------------------------------------------------------
label r3_s4_pe:
    $ talk_pe_minjae = False
    $ talk_pe_soyun = False
    $ talk_pe_harin = False
    $ note_witness = False

    scene bg_12 with fade
    "오후 체육 시간. 선생님이 오시기 전까지 짧은 자유 시간이 주어졌다."
    "저번에는 하린이의 짝을 찾아주느라 허둥지둥했다."
    "하지만 지금의 나는 교실 분위기가 어떻게 돌아가는지 좀 떨어져서 살펴볼 여유가 생겼다."
label inv_pe_r3:

    call screen pe_investigation_r3

    if _return == "minjae_r3":
        $ talk_pe_minjae = True
        scene bg_12 with fade

        if key4_minjae_pattern:
            scene bg_12_blur with dissolve
            show m3 at center_stage with dissolve

            "민재는 운동장에 굴러다니던 축구공을 발로 툭툭 차고 있다."
            "점심시간의 일로 기가 꺾인 탓인지, 평소처럼 아이들을 몰고 다니며 큰소리를 치지 못한다."

            hide m3 with dissolve
            scene bg_12 with dissolve

            n "(민재는 완전히 멈춘 건 아니야. 하지만 적어도 예전처럼 아무렇지 않게 분위기를 주도하지는 못하고 있어.)"

        else:
            scene bg_12_blur with dissolve
            show m3 at center_stage with dissolve

            "민재는 운동장에 굴러다니던 축구공을 발로 툭툭 차고 있다."
            "여전히 거들먹거리고 있지만, 어딘가 행동이 부자연스럽다."

            hide m3 with dissolve
            scene bg_12 with dissolve

            n "(민재는 아직 자기가 뭘 하고 있는지 제대로 의식하지 못하는 것 같아.)"

        jump inv_pe_r3


    elif _return == "soyoon_r3":
        $ talk_pe_soyun = True
        scene bg_12 with fade

        if f_r3_soyoon_coop:
            scene bg_12_blur with dissolve
            show s3 at center_stage with dissolve

            "소윤이는 예서 무리와 조금 떨어진 곳에 서 있었다."
            "하지만 소윤의 시선은 예전처럼 불안하게 흔들리지 않았다."
            "오히려 나와 하린이 쪽을 쳐다보며 짧게 눈을 맞췄다."

            hide s3 with dissolve
            scene bg_12 with dissolve

            n "(소윤이는 이제 완전히 모른 척할 생각은 없어 보여.)"

        else:
            scene bg_12_blur with dissolve
            show s8 at center_stage with dissolve

            "소윤이는 예서 곁에서 억지로 웃으며 대화에 끼려 애쓰고 있다."
            "하지만 웃는 얼굴과 달리, 손끝은 계속 옷자락을 만지작거리고 있었다."

            hide s8 with dissolve
            scene bg_12 with dissolve

            n "(소윤이는 불편함을 느끼고 있어. 그런데 아직 거기서 빠져나오지는 못했어.)"

        jump inv_pe_r3


    elif _return == "harin_r3":
        $ talk_pe_harin = True
        scene bg_12 with fade

        scene bg_12_blur with dissolve
        show h3 at center_stage with dissolve

        "하린이는 구령대 근처에서 묵묵히 신발 끈을 고쳐 매고 있다."
        "그때, 민재가 공을 줍는 척하며 하린의 옆을 스치듯 지나갔다."

        hide h3 with dissolve
        scene bg_12 with dissolve

        "툭."
        "작게 구겨진 종이 뭉치가 하린의 발밑에 떨어졌다."

        n "(...쪽지?)"

        "하린이는 당황한 듯 주변을 살피더니 서둘러 쪽지를 주워 체육복 주머니에 찔러 넣었다."

        $ note_witness = True

        n "아무래도 수상해. 하린에게 물어봐야겠어."

        jump inv_pe_r3


    elif _return == "finish_pe":

        if not note_witness:
            scene bg_12 with fade
            "아직 확인하지 못한 흐름이 있는 것 같다. 조금만 더 지켜보자."
            jump inv_pe_r3

        else:
            scene bg_12 with fade
            "수업 시작을 알리는 선생님의 호루라기 소리가 운동장을 갈랐다."
            jump r3_s4_partner_event


    else:
        jump inv_pe_r3


# ----------------------------------------------------------
# [핵심 이벤트] 짝꿍 정하기와 쪽지의 진실
# ----------------------------------------------------------
label r3_s4_partner_event:
    scene bg_12_blur with dissolve
    show pt1 at center_stage with dissolve
    pt "자, 두 명씩 짝지어서 스트레칭부터 한다. 남는 사람 없게 빨리빨리 뭉쳐!"
    hide pt1 with dissolve

    scene bg_12 with dissolve
    "아이들이 익숙하게 자기 무리를 찾아 흩어졌다."
    "나는 주저 없이 하린이가 있는 곳으로 걸어갔다. 하린이도 나를 보며 작게 안도의 한숨을 내쉬었다."

    if f_r3_soyoon_coop:
        scene bg_12_blur with dissolve
        show s2 at center_stage with dissolve
        s "하린아!"
        hide s2 with dissolve

        scene bg_12 with dissolve
        "스탠드에 있던 소윤이가 가벼운 걸음으로 뛰어왔다."

        scene bg_12_blur with dissolve
        show s9 at center_stage with dissolve
        s "우리 셋이 같이 하자. 선생님, 저희 셋이 해도 되죠?"
        hide s9 with dissolve

        scene bg_12 with dissolve
        "예서와 민재 무리에 있던 아이들이 우리 쪽을 흘끔거렸다."

        if trust_harin >= 5:
            "하린의 입가에 아주 옅은 미소가 번졌다. 셋이서 둥글게 모여 스트레칭을 시작했다."
    else:
        "나와 하린은 마주 보고 서서 서로의 손목을 잡았다."
        "소윤은 예서의 눈치를 보며 결국 예서 무리 쪽으로 황급히 뛰어갔다."

        if trust_harin >= 5:
            "하린이는 씁쓸한 표정이었지만, 내 손을 꽉 잡으며 의지하는 모습을 보였다."

    "한참 동안 셔틀콕이 오가고, 마침내 수업 종료를 알리는 날카로운 호루라기 소리가 울렸다."
    "아이들은 흩어져 배드민턴 라켓과 공을 정리함에 넣기 시작했다."
    "이마에 맺힌 땀을 닦으며 하린과 나란히 수돗가로 향했다."
    "둘 사이에 잠시 정적이 흘렀다."

    scene black with fade
    pause 0.5

    scene bg_7 with fade
    "오후의 햇살 아래 체육 수업이 무사히 끝났다."
    "아이들이 무리 지어 교실로 올라가는 길, 나는 일부러 걸음을 늦춰 하린이와 나란히 계단을 올랐다."

    "앞서가던 소윤이가 뒤를 돌아보았지만, 나는 눈짓으로 먼저 가라는 신호를 보냈다."
    "주변에 다른 아이들이 없는 것을 확인한 후, 나는 목소리를 낮춰 물었다."

    n "하린아, 아까 민재가 던지고 간 거... 뭐야?"

    "하린의 어깨가 흠칫 떨렸다."
    "하린은 겁에 질린 눈으로 위아래를 살핀 뒤, 주머니에서 구겨진 쪽지를 조심스럽게 꺼냈다."

    "날카롭고 삐뚤빼뚤한 글씨체."
    "『야, 다 장난인 거 알지?"
    "그러니까 괜히 예민하게 받아들이지 말고,"
    "분위기 흐리지는 말자.』"

    "저번에 책상 밑에서 주웠던 그 쪽지였다."
    "그때는 찢어져 있어서 무슨 말인지 몰랐는데, 이제 다 읽혔다."
    "장난이었다고 해 놓고, 말도 못 하게 막는 거였다."

    menu:
        "장난이라고 넘길 말은 아니야. 네가 불편했다면 그건 중요한 일이야.":
            $ trust_harin += 2

            scene bg_7_blur with dissolve
            show h5 at center_stage with dissolve

            h "근데… 진짜 내가 예민하게 받아들이는 걸까 봐."
            h "애들은 그냥 장난이었다고 하는데, 나만 심각하게 생각하는 것 같아서."
            h "내가 말하면… 진짜 분위기 흐리는 애가 될까 봐..."

            hide h5 with dissolve
            scene bg_7 with dissolve 

            n "네가 분위기를 흐리는 게 아니야."
            n "불편한 일을 불편하다고 말할 수 없게 만드는 게 문제야."
            n "그걸 혼자 참게 두는 것도 잘못된 거고."
            
            
            n "오늘 방과 후에도 나랑 같이 하교하자."
            n "혼자 두지 않을게."

            scene bg_7_blur with dissolve
            show h16 at center_stage with dissolve
            "하린이의 축 쳐저 있던 고개가 서서히 올라왔다."
            "하린이는 쪽지를 쥔 손에 천천히 힘을 풀었다."
            hide h16 with dissolve

            $ f_r3_stay_together = True

        "이런 걸 그냥 받고 넘기면 안 돼. 증거 있잖아, 이거 선생님한테 보여드리자.":
            $ trust_harin -= 1

            scene bg_7_blur with dissolve
            show h4 at center_stage with dissolve
            h "안 돼! 그..그러면... 아냐 제발, 모른 척해 줘."
            hide h4 with dissolve

            scene bg_7 with dissolve
            "하린이는 기겁하며 쪽지를 빼앗듯 가져가 주머니에 쑤셔 넣었다."
            "쪽지에는 대놓고 경고가 적혀 있었다."
            "당장 내일이 무서운 하린이에게 무작정 선생님께 가자고 한 건 너무 성급했다."
            "내 말이 오히려 하린이를 더 겁먹게 만들었다."

    "하린이는 여전히 불안해 보였지만, 적어도 이번에는 쪽지를 받은 뒤 혼자 두지는 않았다."
    "우리는 말없이 남은 계단을 올라 교실로 향했다."

    jump r3_s6_afterschool



label r3_s6_afterschool:
    scene bg_14 with fade
    "종례가 끝나고 아이들이 썰물처럼 빠져나갔다."
    "교실에는 나와 하린, 그리고 가방을 멘 예서와 민재가 남아 있었다."

    if f_r3_soyoon_coop:
        "내 옆에는 소윤이도 자리를 지키고 서 있었다."

    "우리가 교실 뒷문을 향해 걸음을 옮기려 할 때, 예서가 앞을 가로막았다."

    scene bg_14_blur with dissolve
    show y3 at center_stage with dissolve
    y "야, 오하린. 너 진짜 그냥 갈 거야?"
    "예서가 주머니에서 스마트폰을 꺼내 화면을 톡톡 두드렸다."
    y "오늘 그냥 가면, 나 이거 실수로 반 단톡방에 올릴지도 모르는데."
    hide y3 with dissolve

    scene bg_14 with dissolve
    "예서의 액정에는 하린의 사진이 떠 있었다."
    "아이들이 점심시간에 돌려보며 비웃었던, 바로 그 우스꽝스러운 사진이었다."
    "점심시간에 우리가 같이 있어서 못 꺼냈던 그 사진을, 결국 꺼낸 거다."
    scene bg_14_blur with dissolve
    show h16 at center_stage with dissolve
    "하린의 얼굴이 순식간에 하얗게 질렸다. 아까 체육 시간에 쪽지가 왜 왔는지, 이제 확실히 알 것 같았다."
    hide h16 with dissolve
    scene bg_14 with dissolve

    if trust_harin >= 5 and f_r3_soyoon_coop:
        "예전의 하린이었다면 여기서 무너졌을지도 모른다."
        "하지만 하린은 떨리는 손을 꽉 쥐더니, 예서의 눈을 똑바로 쳐다보며 입을 열었다."

        scene bg_14_blur with dissolve
        show h21 at left_stage with dissolve
        h "…그거 지워."

        show y4 at right_stage with dissolve
        y "뭐?"

        h "당장 지우라고. 그거 범죄야."
        hide h21
        hide y4
        with dissolve

        scene bg_14 with dissolve
        "예서가 당황해서 아무 말도 못 하는 사이, 소윤이가 한발 앞으로 나섰다."

        scene bg_14_blur with dissolve
        show s10 at center_stage with dissolve
        s "예서야, 그만해. 너 지금 선 넘었어. 그거 올리면 나도 가만히 안 있어."
        hide s10 with dissolve

        scene bg_14 with dissolve
        "소윤이의 단호한 태도에 예서의 눈동자가 흔들렸다."
        "나는 굳은 얼굴로 서 있는 민재를 향해 시선을 던졌다."

        if key4_minjae_pattern:
            "아침부터 기운이 빠져 있던 민재는, 상황이 복잡해지자 예서의 팔을 툭 쳤다."

            scene bg_14_blur with dissolve
            show m1 at center_stage with dissolve
            m "아, 됐어... 야, 그냥 가자. 나 학원 늦겠어."
            hide m1 with dissolve

            $ trust_minjae += 2

        else:
            "민재는 입술을 깨물며 우리 쪽을 봤지만, 셋이 뭉쳐 있는 모습에 더 다가오지는 못했다."

            scene bg_14_blur with dissolve
            show m1 at center_stage with dissolve
            m "…진짜 이상하네, 얘네."
            hide m1 with dissolve

        scene bg_14 with dissolve
        "예서는 입술을 삐죽거리며 휴대폰을 가방에 집어넣었다. 민재와 예서는 뒷문을 쾅 닫고 교실을 나갔다."
        "교실을 누르고 있던 게 한꺼번에 빠져나간 것 같았다."

        jump r3_s7_final_bathroom_talk

    elif trust_harin >= 5:
        "하린이는 떨리는 목소리로, 하지만 분명하게 말했다."

        scene bg_14_blur with dissolve
        show h21 at left_stage with dissolve
        h "…그거 올리면 나도 선생님한테 다 말할 거야."
        
        show y6 at right_stage with dissolve

        "예서의 눈이 커졌다. 항상 고개만 숙이던 하린이가 처음으로 맞서는 거였다."
        n "예서야. 사진 유포는 범죄야. 너도 알잖아."

        hide y6 with dissolve
        show y4 at right_stage with dissolve

        "예서는 나와 하린이를 번갈아 보더니, '어이없어'라고 작게 중얼거리며 휴대폰을 가방에 넣었다."
        "둘은 교실을 나갔지만, 하린이의 표정에는 여전히 걱정이 남아 있었다."

        hide h21 
        hide y4 
        with dissolve

        scene bg_14 with dissolve

        jump r3_s7_final_bathroom_talk

    else:
        "사진을 본 순간, 하린이가 고개를 푹 숙였다."

        scene bg_14_blur with dissolve
        show h3 at center_stage with dissolve
        h "…알았어. 내가 할게. 그러니까 그거 아무한테도 보여주지 마."
        hide h3 with dissolve

        scene bg_14 with dissolve
        n "하린아, 안 돼. 지금 들어주면 다음에도 계속 이럴 거야."
        "내가 말렸지만 하린이는 내 손을 조심스럽게 밀어냈다."

        scene bg_14_blur with dissolve
        show h5 at center_stage with dissolve
        h "오늘 고마웠어… 너는 그냥 먼저 가."
        hide h5 with dissolve

        scene bg_14 with dissolve
        "하린이는 빗자루를 잡고 고개를 들지 못했다. 예서가 나를 빤히 쳐다보며 가방을 고쳐 멨다."
        n "(내가 나름대로 노력해 봤지만, 한 번에 모든 걸 바꾸기엔 아직 내 힘이 모자란 것 같다.)"

        jump r3_s7_final_bathroom_talk


# ----------------------------------------------------------
# R3-S7. 다음 날 아침 — 복도 대화
# ----------------------------------------------------------
label r3_s7_final_bathroom_talk:
    scene black with fade
    pause 0.8

    scene bg_7 with fade

    if trust_harin >= 5 and f_r3_soyoon_coop:
        "화요일 아침. 교실로 향하는 복도가 어쩐지 어제보다 조금 밝게 느껴졌다."
        "하린은 나를 발견하자 먼저 멈춰 서서 나를 마주 보았다."

    elif trust_harin >= 5:
        "화요일 아침. 복도는 어제와 크게 다르지 않았다."
        "하린이는 화장실에서 나오다 나와 마주쳤다. 어제만큼 불안해 보이진 않았지만, 아직 긴장한 기색이 역력했다."

    else:
        "화요일 아침. 복도가 어제보다 더 무겁게 느껴졌다."
        "화장실 앞을 지나가는데, 하린이가 고개를 푹 숙인 채 걸어 나오고 있었다."
        "어제 예서 앞에서 고개를 숙이던 모습이 그대로였다."
        "하린이는 나를 보더니 잠깐 멈칫했지만, 시선을 피하며 지나가려 했다."

    menu:
        "선생님께 말씀드리는 건 어때? 내가 같이 갈게.":
            $ trust_harin += 2

            if trust_harin >= 4:
                scene bg_7_blur with dissolve
                show h21 at center_stage with dissolve
                h "…응. 어제 네가 옆에 있어 줬을 때 생각했어."
                h "더 이상은 숨기고 싶지 않다고."
                h "선생님한테... 말씀드리고 싶어."
                hide h21 with dissolve

                if f_r3_soyoon_coop:
                    scene bg_7_blur with dissolve
                    show s10 at center_stage with dissolve
                    s "나도 같이 갈게. 어제 예서가 사진으로 협박한 거, 내가 같이 말해 줄 수 있어."
                    hide s10 with dissolve

                    scene bg_7_blur with dissolve
                    show h28 at center_stage with dissolve
                    h "소윤아... 고마워."
                    hide h28 with dissolve
                else:
                    scene bg_7 with dissolve
                    "소윤이는 멀리서 우리를 지켜보다가 고개를 돌려 교실로 들어가 버렸다."
                    "조금 쓸쓸해 보였지만, 하린이는 내 손을 꽉 잡았다."

                scene bg_7 with dissolve
                "우리는 나란히 교무실 쪽으로 걸어갔다. 하린이의 발걸음 소리가 어느 때보다 단단하게 들렸다."
            else:
                scene bg_7_blur with dissolve
                show h23 at center_stage with dissolve
                h "…선생님한테? 근데 말해 봤자 걔네가 더 심하게 하면 어떡해..."
                hide h23 with dissolve

                scene bg_7 with dissolve
                n "내가 같이 갈게. 혼자 말하는 거 아니야."

                scene bg_7_blur with dissolve
                show h5 at center_stage with dissolve
                h "…알겠어. 같이 가 줘."
                hide h5 with dissolve

                scene bg_7 with dissolve
                "확신에 찬 대답은 아니었지만, 적어도 혼자 도망치지는 않았다."

            jump r3_s8_teacher_room

        "말하기 힘들면 억지로 안 해도 돼. 그냥 네 곁에 있을게.":
            $ trust_harin += 2
            "나는 더 묻지 않고 하린의 옆에 가만히 서 있었다. 그 침묵을 기다려주기로 했다."

            if trust_harin >= 4:
                scene bg_7_blur with dissolve
                show h5 at center_stage with dissolve
                h "…어제 예서가 사진 보여줬을 때, 사실 진짜 무서웠어."
                h "근데 이제는 알아. 내가 피한다고 끝나는 게 아니라는 거."
                h "선생님한테... 말씀드리고 싶어."
                hide h5 with dissolve

                scene bg_7 with dissolve
                jump r3_s8_teacher_room
            else:
                scene bg_7_blur with dissolve
                show h4 at center_stage with dissolve
                h "…고마워. 근데 나 아직 잘 모르겠어."
                h "어제 일도 그렇고... 말해 봤자 더 나빠질 것 같아서."
                hide h4 with dissolve

                scene bg_7 with dissolve
                n "(하린이는 아직 준비가 안 됐다. 억지로 끌고 갈 수는 없어.)"
                jump r3_s8_teacher_room


# ----------------------------------------------------------
# R3-S8. 교무실 — 데이터에 기반한 보고
# ----------------------------------------------------------
label r3_s8_teacher_room:
    scene bg_10 with fade
    $ case_score = 0

    if key1_structure:
        $ case_score += 1
    if note_chat:
        $ case_score += 1
    if note_witness:
        $ case_score += 1
    if f_r3_soyoon_coop:
        $ case_score += 1

    "교무실 안. 담임 선생님은 우리의 이야기를 묵묵히 들어주셨다."

    if case_score >= 2:
        n "선생님. 이건 하루 장난이 아니라 계속된 일이에요."

        if f_r3_soyoon_coop:
            scene bg_10_blur with dissolve
            show s3 at center_stage with dissolve
            s "맞아요. 민재랑 예서가 사진을 찍어서 돌려보고, 하린이 의견은 아예 무시하는 걸 저도 여러 번 봤어요."
            hide s3 with dissolve
            scene bg_10 with dissolve

        if note_chat:
            n "단톡방에서도 하린이를 몰아붙이는 말들이 계속 올라왔어요."
        if note_witness:
            n "체육 시간에도 민재가 하린이 옆을 일부러 스치듯 지나가면서 쪽지를 떨어뜨렸어요."

        "우리가 모은 이야기들이 하나로 이어지자 선생님의 표정이 무겁게 굳었다."

        scene bg_10_blur with dissolve
        show t5 at center_stage with dissolve
        t "너희들이 이렇게 용기 내서 하나하나 말해줘서 정말 다행이다. 이건 절대 장난으로 넘길 일이 아니야."
        hide t5 with dissolve
        show t6 at center_stage with dissolve
        t "우선 하린이가 안심할 수 있게 상담실(위클래스)과 연결할게."
        t "관련 아이들은 오늘 중으로 따로 불러서 지도하마."
        hide t6 with dissolve

        scene bg_10 with dissolve
        $ f_r3_teacher_support = True

    else:
        n "선생님. 하린이가 많이 힘들어 보여요. 그냥 기분 문제로 넘길 상황은 아닌 것 같아요."
        "나는 그동안 모은 정보들을 차근히 설명했지만, 아직 당장 강하게 움직이기엔 근거가 부족했다."

        scene bg_10_blur with dissolve
        show t6 at center_stage with dissolve
        t "네가 이렇게 걱정해 주는 건 정말 중요해. 우선 하린이 상태를 살피고 상황을 파악해 볼게."
        hide t6 with dissolve

        scene bg_10 with dissolve
        $ f_r3_teacher_support = False

    jump ending_check


# ----------------------------------------------------------
# 엔딩 분기
# ----------------------------------------------------------
label ending_check:
    scene black with fade
    "며칠 뒤. 교실의 공기가 조금씩 바뀌기 시작했다."

    if f_r3_soyoon_coop and f_r3_teacher_support and trust_harin >= 5:
        jump ending_true

    elif f_r3_teacher_support and trust_harin >= 3:
        jump ending_step_a

    elif f_r3_stay_together or trust_harin >= 4:
        jump ending_normal

    else:
        jump ending_bad


# ==========================================================
# [경로 1] TRUE END: 완벽한 연대
# ==========================================================
label ending_true:
    $ ending_type = "true"
    scene black with fade
    pause 0.6

    # ------------------------------------------------------
    # 장면 1 — 말씀드린 밤
    # ------------------------------------------------------
    scene bg_3 with fade
    "선생님께 모든 걸 말씀드리고 집에 돌아온 날 밤,"

    play sound "audio/bed_sheets_moving.mp3"
    "나는 침대에 누워서도 한참 잠이 오지 않았다."
    stop sound
    "무서워서가 아니었다."
    "뭔가 오래 막혀 있던 게 '툭' 하고 빠진 것 같은 기분이었다."
    "이상하게 자꾸 눈물이 날 것 같아서 이불을 머리끝까지 끌어올렸다."

    n "(하린이는… 내일 괜찮을까.)"
    n "(소윤이는 내일도 내 편에 있어 줄까.)"
    n "(…근데 오늘 내가 한 일이 진짜로 뭔가를 바꿀 수 있을까.)"

    scene black with fade
    pause 0.4

    # ------------------------------------------------------
    # 장면 2 — 다음 날 아침, 교문
    # ------------------------------------------------------
    scene bg_16 with fade
    "다음 날 아침. 교문 앞."
    "평소에는 혼자 고개를 숙이고 들어오던 하린이가,"
    "오늘은 소윤이와 나란히 걸어 들어오고 있었다."
    "소윤이가 나를 먼저 보고 손을 크게 흔들었다."

    scene bg_16_blur with dissolve
    show s9 at left_stage with dissolve
    s "얘들아! 같이 가자!"
    show h28 at right_stage with dissolve

    "나는 작게 웃으며 뛰어가 둘 옆에 섰다."
    "하린이는 여전히 말수가 적었다."
    "그래도 가방끈을 꽉 쥐고 있던 손이, 오늘은 조금 덜 떨리고 있었다."
    hide s9
    hide h28
    with dissolve
    scene bg_16 with dissolve

    # ------------------------------------------------------
    # 장면 3 — 교실, 담임의 조회
    # ------------------------------------------------------
    scene black with fade
    pause 0.8

    scene bg_17 with fade

    "교실에 들어서자 공기가 달랐다."
    "민재와 예서는 각자 따로 앉아 있었다."
    "어제 방과 후에 선생님이 두 사람을 오래 따로 부르셨다고 했다."
    "무슨 이야기가 오갔는지는 모르지만,"
    "아침 자습 시간 내내 둘 다 고개를 들지 않았다."

    "조회 시간에 선생님이 평소보다 조용한 목소리로 말씀하셨다."

    scene bg_17_blur with dissolve
    show t5 at center_stage with dissolve
    t "얘들아. 오늘은 선생님이 다 같이 나누고 싶은 이야기가 있어."
    t "직접 때리거나 욕하지 않아도,"
    t "누군가를 자꾸 밀어내고, 끼워주지 않고, 웃음거리로 만드는 것"
    hide t5 with dissolve
    show t7 at center_stage with dissolve
    t "그것도 분명한 폭력이야."
    t "그리고 보고도 모른 척하는 것은,"
    t "그 폭력이 계속되게 놔두는 일이기도 해."
    hide t7 with dissolve

    scene bg_17 with dissolve
    "교실이 평소와 다르게 조용했다."
    "평소 같으면 누군가 킥킥 웃거나 지루하다는 표정을 지었을 텐데."
    "오늘은 아무도 그러지 않았다."

    scene bg_17_blur with dissolve
    show t1 at center_stage with dissolve
    t "선생님은 오늘부터 하린이 편에, 그리고 이 교실의 모든 사람 편에 설 거야."
    t "누구든 힘들면 혼자 참지 말고 말해줘."
    t "선생님도 놓치는 게 있을 수 있으니까, 너희가 도와줘야 해."
    hide t1 with dissolve
    show h5 at center_stage with dissolve
    "하린이의 어깨가 아주 살짝 떨렸다."
    "내 자리에서도 보였다."
    "고개를 숙인 채로, 하린이가 아주 조용히 눈물을 닦고 있었다."
    "울고 있는데도 그 모습이 무섭지 않았다."
    "오랫동안 꾹꾹 참아왔던 게 처음으로 터진 것 같은, 그런 눈물이었다."
    hide h5 with dissolve
    scene bg_17 with dissolve


    # ------------------------------------------------------
    # 장면 4 — 위클래스 상담실
    # ------------------------------------------------------
    scene black with fade

    "그날 오전 수업이 끝난 뒤,"
    "하린이는 담임 선생님의 안내로 위클래스 상담실에 가게 되었다."

    scene cg_t2 with dissolve

    wt "하린아, 여기서는 바로 말하지 않아도 괜찮아."
    wt "천천히 해도 되고, 말하고 싶지 않은 건 지금 말하지 않아도 괜찮아."

    "위클래스 선생님은 다그치지 않았고,"
    "무슨 일이 있었는지 단정하지도 않았다."
    "그저 하린이가 안전하다고 느낄 수 있도록 천천히 말을 건네고 있었다."

    wt "네 잘못이 아닌 일을, 네가 혼자 버티고 있었던 거라면"
    wt "이제는 어른들이 같이 알아야 해."
  
    scene black with fade
    pause 0.5

    scene bg_7 with fade
    "쉬는 시간."
    "복도를 지나가는데, 멀리서 하린이가 걸어오는 게 보였다."

    scene bg_7_blur with dissolve
    show h28 at center_stage with dissolve
    "가방을 메고 정면을 바라보며 걸어오는 하린이."
    "예전의 축 처진 어깨와는 달랐다. 고개를 들고, 똑바로 앞을 보고 있었다."
    hide h28 with dissolve

    scene bg_7 with dissolve
    "나와 눈이 마주치자 하린이가 아주 작게 고개를 끄덕였다."
    "그게 인사였다. 하린이 방식의."

    # ------------------------------------------------------
    # 장면 5 — 급식실
    # ------------------------------------------------------
    
    scene black with fade

    "점심시간."
    "원래라면 하린이가 구석 자리를 향해 걸어갔을 시간이었다."
    "오늘은 달랐다."
    
    play music "audio/bgm_true_warm.mp3" fadein 2.0 fadeout 1.0
    scene cg_t1 with dissolve
    "하린이가 식판을 들고, 망설임 없이 우리 쪽으로 걸어왔다."
    "소윤이가 자기 옆 의자를 탁, 하고 끌어당겼다."

    s "여기 앉아, 하린아."
    "하린이가 의자에 앉기 전에 아주 짧게 우리를 한 번 쳐다봤다."
    "'나 진짜 여기 앉아도 돼?'"
    "그렇게 묻는 눈빛이었다."
    "소윤이와 나는 동시에 고개를 끄덕였다."

    "하린이가 천천히 자리에 앉았다."
    "그러고는 아주 작은 목소리로 말했다."

    h "...오늘 국, 맛있겠다."

    "그게 뭐라고,"
    "내 코끝이 찡해졌다."
    "그동안 하린이가 급식실에서 먼저 입을 연 걸 본 적이 거의 없었다."
    "'오늘 국 맛있겠다'는 짧은 한마디가"
    "이렇게 큰 말이 될 수 있다는 걸, 나는 오늘 처음 알았다."

    s "맛있지. 나 이거 제일 좋아해."

    h "...나도."

    "하린이가 처음으로 아주 작게 웃었다."
    "눈이 살짝 접히는 그런 웃음이었다."
    "모르는 사람은 웃은 건지도 모를 만큼 아주 작은 웃음."
    "그런데 나는 분명히 알아봤다."

    n "(이 웃음을 보려고,)"
    n "(그 많은 시간을 다시 돌아왔던 거구나.)"

    # ------------------------------------------------------
    # 장면 6 — 며칠이 흐른 뒤
    # ------------------------------------------------------
    scene black with fade
    pause 0.8

    scene cg_s3 with fade

    "그 뒤로 며칠이 흘렀다."
    "교실이 하루아침에 완벽하게 바뀐 건 아니었다."
    "하린이는 여전히 말수가 적고,"
    "쉬는 시간에 혼자 창밖을 보는 날도 있었다."
    "민재와 예서는 복도에서 마주칠 때면 아직 내 눈을 잘 피한다."

    "그래도 분명히 달라진 게 있다."
    "하린이가 혼자 울지 않는다."
    "하린이가 울 것 같은 표정을 지으면,"
    "소윤이가 먼저 알아차리고 화장실로 같이 가 준다."
    "나도 간다. 그냥 옆에 있어 주는 것만으로도 달라지는 게 있다는 걸, 이제는 안다."

    scene bg_15 with fade
    "위클래스 선생님도 일주일에 한 번씩 하린이를 만나주신다."
    "하린이는 그 시간이 제일 편하다고 했다."
    "'혼내는 사람도 없고, 억지로 괜찮냐고 묻지도 않아서.'"

    # ------------------------------------------------------
    # 장면 7 — 금요일 방과 후
    # ------------------------------------------------------
    scene black with fade

    scene cg_t3 with dissolve

    "금요일 방과 후."
    "노을이 교실 바닥까지 길게 드리워져 있었다."
    "나와 소윤이, 하린이는 아무도 없는 교실에서 늦게까지 같이 청소를 했다."

    "하린이가 빗자루를 들고 칠판 앞을 정리하다가 문득 멈추더니 말했다."

    h "있잖아."
    h "나, 학교 오는 게 전보다 덜 무서워."
    h "아침에 교문 들어설 때, 아직도 심장이 좀 빨리 뛰긴 하는데…"
    h "그래도 이제는, 교실 문을 열기 전에 너희 얼굴이 먼저 떠올라."

    "소윤이가 빗자루를 그대로 내리고 하린이를 쳐다봤다."
    "하린이의 눈가가 다시 젖어 있었다."
    "그런데 입꼬리는 분명히 올라가 있었다."

    s "그럼 내일부터는 진짜 같이 오자. 문구점 앞에서 만나."

    h "...응."
  
    # ------------------------------------------------------
    # 장면 8 — 주인공의 독백
    # ------------------------------------------------------
    scene black with fade

    n "(내가 대단한 일을 한 건 아니었다.)"
    n "(처음엔 무서웠고,)"
    n "(어떻게 해야 할지 몰라서 계속 헤맸고,)"
    n "(같은 날을 몇 번이나 되풀이한 뒤에야 겨우 방법을 찾았다.)"

    n "(돌이켜보면 내가 한 건 정말 별게 아니었다.)"
    n "(하린이가 지나갈 때 한 번 더 쳐다본 것.)"
    n "(식판을 들고 하린이 옆에 앉은 것.)"
    n "(소윤이한테 '너도 그렇게 생각했지?'라고 먼저 물어본 것.)"
    n "(선생님께 '이건 그냥 장난이 아니에요'라고 말씀드린 것.)"

    n "(하나하나는 진짜 별것 아닌 일이었다.)"
    n "(그런데 그 작은 일들이 모이니까,)"
    n "(누군가의 하루가 바뀌었다.)"
    n "(누군가가 다시 웃었다.)"

    n "(그게, 내가 이번에 배운 거였다.)"

    stop music fadeout 3.0
    scene black with fade
    pause 0.8

    centered "{size=34}{color=#FFFFFF99}엔딩{/color}{/size}\n\n{size=54}{color=#C8FFC8}{b}연대 엔딩: 함께 지켜낸 교실{/b}{/color}{/size}\n\n{size=28}{color=#F2FFF2}서로의 편이 된 아이들{/color}{/size}"
    pause 2.5

    # TRUE END 이후, 조건을 만족한 경우에만 숨겨진 후일담으로 이어짐.
    if key4_minjae_pattern and f_r3_minjae_weakness and note_witness and f_r3_soyoon_coop:
        scene black with fade
        pause 1.0

        centered "{size=34}{color=#FFF4DD}그리고, 며칠 뒤.{/color}{/size}"
        pause 1.8

        centered "{size=30}{color=#FFF4DD}끝났다고 생각했던 이야기는\n아직 한 걸음 더 남아 있었다.{/color}{/size}"
        pause 2.2

        jump ending_hidden
    else:
        jump ending_epilogue


# ==========================================================
# [경로 2] STEP END: 천천히 아물어가는 마음
# ==========================================================
label ending_step_a:
    $ ending_type = "step_a"
    scene black with fade
    pause 0.6

    # ------------------------------------------------------
    # 장면 1 — 구조는 움직였다
    # ------------------------------------------------------
    "선생님은 우리 이야기를 허투루 듣지 않으셨다."
    "단톡방에서 오간 말들, 급식실의 빈자리,"
    "그리고 체육 시간에 하린이 발밑에 떨어졌던 쪽지까지."
    "선생님은 우리가 확인한 정황들을 하나씩 짚어 주셨다고 했다."
    "그게 왜 단순한 장난이 아니라 누군가를 몰아세우는 행동인지,"
    "민재와 예서에게도 따로 설명해 주셨다고 했다."

    scene bg_15 with dissolve
    "위클래스 선생님도 하린이를 직접 만나 주셨다."
    "일주일에 한 번씩, 조용한 상담실에서."

    scene bg_17 with dissolve
    "겉으로 보기엔 교실이 많이 달라졌다."
    "민재 무리는 더 이상 대놓고 웃지 못했고,"
    "단톡방에서 누군가의 사진을 돌려보는 일도 사라졌다."
    "소윤이도 예전처럼 아무렇지 않은 얼굴로 웃지는 못했다."

    "다만, 소윤이가 완전히 나서 준 것은 아니었다."
    "하린이의 편에 서고 싶어 하는 것 같으면서도,"
    "막상 모두가 보는 앞에서는 한 발 물러서 있었다."

    "그런데도 하린이는 쉽게 웃지 않았다."

    "내가 옆에 앉으면 작게 고개를 끄덕였다."
    "내가 말을 걸면 짧게 대답했다."
    "하지만 먼저 내 이름을 부르거나,"
    "자기 이야기를 꺼내는 일은 드물었다."

    scene cg_t4 with fade

    "점심시간, 하린이는 우리 테이블에 앉았다."
    "근데 내 바로 옆이 아니라,"
    "한 자리 건너 맞은편에 앉았다."

    "소윤이는 조금 떨어진 자리에서 식판만 내려다보고 있었다."
    "그러다 하린이 쪽을 힐끗 보고,"
    "빈 물컵을 조용히 하린이 쪽으로 밀어 주었다."

    "하린이는 소윤이 쪽을 제대로 보지는 못했다."
    "소윤이도 더 말을 걸지는 못했다."
    "하지만 적어도 이번에는,"
    "아무것도 모르는 척 웃고 있지는 않았다."

    "나는 그 어색한 거리감이 자꾸 마음에 걸렸다."
    "도와주고 싶은 마음이랑, 진짜로 나서는 건"
    "아직 한 걸음 차이가 있었다."

    n "(내가 뭔가 부족했던 걸까.)"
    n "(더 천천히 다가갔어야 했나.)"
    n "(아니면, 너무 급하게 '다 해결됐어!'라고 굴었던 걸까.)"

    # ------------------------------------------------------
    # 장면 3 — 복도 창가
    # ------------------------------------------------------
    scene black with fade

    "그 주 금요일."


    play music "audio/bgm_step_gentle.mp3" fadein 2.5 volume 0.6
    scene cg_s1 with dissolve
    "나는 복도 창가에 혼자 서 있는 하린이를 봤다."
    "체육 수업이 끝난 운동장을 내려다보고 있었다."

    "나는 조심스럽게 다가가 옆에 섰다."
    "아무 말 없이 같이 운동장을 봤다."

    "한참 뒤, 하린이가 먼저 입을 열었다."

    h "있잖아."
    h "네가 선생님한테 말해준 거… 진짜 고마워."
    h "근데 나, 아직도 교실이 조금 무서워."
    h "사람들이 다 내 얘기 하고 있는 것 같고,"
    h "누가 쳐다보면 또 뭔가 잘못한 건가 싶고."

    h "그래서 너한테 다가가는 게 아직 힘들어."
    h "네가 싫어서가 아니야. 진짜 아니야."
    h "그냥 내가… 아직 누구한테든 마음을 다 열 준비가 안 된 것 같아."
   
    "하린이가 말하는 동안 나는 입술만 깨물고 있었다."
    "뭐라고 대답해야 할지 몰랐다."

    h "미안해."

    n "(미안하다고 말할 사람은 네가 아니잖아.)"
    "나는 그 말을 입 밖으로 꺼내지는 못하고, 대신 천천히 고개를 저었다."

    # ------------------------------------------------------
    # 장면 4 — 주인공의 깨달음
    # ------------------------------------------------------
    scene black with fade

    n "(나는 조금 욕심을 부렸던 것 같다.)"
    n "(내가 여기까지 끌고 왔으니까,)"
    n "(하린이가 이제 막 웃어줘야 뭔가 '성공'한 것 같은 기분이 들어서.)"

    n "(근데 하린이가 혼자 버텨온 시간은 정말 길었다.)"
    n "(며칠 만에 전부 녹을 리가 없었다.)"

    n "(내가 할 일은,)"
    n "(하린이가 다시 마음을 열 수 있을 때까지,)"
    n "(그 속도에 맞춰서 옆에 있어 주는 것이었다.)"
    n "(내가 원하는 빠르기가 아니라, 하린이가 편한 빠르기로.)"

    # ------------------------------------------------------
    # 장면 5 — 작은 변화
    # ------------------------------------------------------
    scene black with fade

    "그날 오후."
    scene cg_s2 with dissolve

    "하교 시간에 하린이가 먼저 내게 와서 우유를 하나 건넸다."
    "급식실에서 남은 거라고, 작게 웃으며."

    "그리고 하린이는 먼저 뒤돌아 교실을 나갔다."
    "평소처럼 천천히, 조용히."
   
    "그런데 그 뒷모습이 예전과는 달랐다."
    "예전엔 '사라지는 뒷모습' 같았다면,"
    "오늘은 '내일 다시 만날 뒷모습'이었다."

    n "(아직은 어색해.)"
    n "(한 자리 건너에 앉은 거리도,)"
    n "(나한테 한마디 하고 먼저 돌아서는 그 몇 걸음도.)"

    n "(근데 괜찮아.)"
    n "(하린이는 지금 아물고 있는 중이니까.)"
    n "(상처는 원래 시간이 걸리는 거니까.)"

    n "(나는 그 옆에서, 급할 것 없이 기다려주면 돼.)"

    stop music fadeout 3.0
    scene black with fade
    pause 0.8

    centered "{size=34}{color=#FFFFFF99}엔딩{/color}{/size}\n\n{size=54}{color=#A0D8E6}{b}회복 엔딩: 천천히 아물어 가는 마음{/b}{/color}{/size}\n\n{size=28}{color=#EAF8FF}하린이가 편한 만큼 가까워지는 길{/color}{/size}"
    pause 2.5

    jump ending_epilogue


# ==========================================================
# [경로 3] NORMAL END: 한 사람의 용기
# ==========================================================
label ending_normal:
    $ ending_type = "normal"
    scene black with fade
    pause 0.6

    # ------------------------------------------------------
    # 장면 1 — 소윤의 침묵
    # ------------------------------------------------------
    scene bg_17 with fade
    "소윤이는 끝까지 같이 나서주지 않았다."
    "나는 그 사실이 한동안 서운했다."
    "같이 본 것이 분명한데,"
    "같이 느낀 것도 분명한데,"
    "소윤이는 끝내 '난 잘 몰라'라는 얼굴을 유지했다."

    "그래도 선생님은 내 말을 그냥 흘려듣지 않으셨다."
    "쉬는 시간마다 복도를 살피고,"
    "하린이 상태를 먼저 확인하고,"
    "교실 안 분위기도 전보다 훨씬 가까이 들여다보셨다."

    "민재 무리도 예전처럼 대놓고 굴지는 못하게 됐다."
    "선생님의 시선이 있는 동안은."

    # ------------------------------------------------------
    # 장면 2 — 하린과 나, 단둘의 길
    # ------------------------------------------------------
    scene black with fade
    pause 0.8

    scene cg_s4 with fade

    "하린이는 결국 반 전체 안에서 편해지지는 못했다."
    "쉬는 시간에도 혼자 책을 읽었고,"
    "점심시간엔 여전히 구석 자리를 선호했다."

    "달라진 건 하나였다."
    "그 구석 자리 맞은편에 내가 있었다."

    "매일 그런 건 아니었다."
    "어떤 날은 하린이가 나한테 '오늘은 혼자 먹고 싶어'라고 말했다."
    "그러면 나는 '응, 그래'라고 하고 내 자리로 갔다."
    "미안해하지도 않고, 서운해하지도 않고."

    "그 대신 그다음 날엔 또 맞은편에 앉았다."
    "그게 우리 둘의 방식이었다."

    # ------------------------------------------------------
    # 장면 3 — 방과 후의 복도
    # ------------------------------------------------------
    scene black with fade
    pause 0.5

    play music "audio/bgm_normal_quiet.mp3" fadein 2.0 volume 0.5
    scene bg_7 with fade

    "어느 날 방과 후."
    "노을이 길게 드리운 복도."
    "하린이가 내 소매 끝을 아주 살짝 잡아당겼다."

    scene bg_7_blur with dissolve
    show h23 at center_stage with dissolve
    h "나… 어제 학교 안 오고 싶었어."
    h "아침에 진짜 가방을 안 쌀 뻔했어."
    hide h23 with dissolve
    show h28 at center_stage with dissolve
    h "근데 네가 어제 '내일 봐'라고 했던 게 자꾸 생각났어."
    h "아무도 나한테 안 기다려줄 줄 알았는데,"
    h "한 명은 기다리고 있을지도 모른다고 생각하니까…"
    h "못 빼먹겠더라."
    hide h28 with dissolve

    scene bg_7 with dissolve
    "하린이가 말하는 동안 나는 아무 말도 하지 못했다."
    "그냥 하린이 손에 조금 더 힘을 주고 복도를 걸었다."

    # ------------------------------------------------------
    # 장면 4 — 주인공의 독백
    # ------------------------------------------------------
    scene black with fade

    n "(반 전체를 한 번에 바꾸지는 못했다.)"
    n "(민재 무리는 여전히 자기들끼리 웃고 떠들고,)"
    n "(소윤이는 여전히 먼 쪽에 앉아 있다.)"

    n "(그래도 하린이 눈에서,)"
    n "(예전처럼 꽉 막혀 있던 게 사라졌다.)"

    n "(나는 알게 됐다.)"
    n "(누군가에게는 한 사람의 진심만으로도,)"
    n "(학교에 올 이유가 될 수 있다는 걸.)"

    n "(교실 전체를 바꾸는 건,)"
    n "(아직 나한테는 너무 벅찬 일이었다.)"
    n "(그래도 하린이 한 명은 혼자 두지 않았다.)"
    n "(그거 하나만큼은 정말 잘한 일이었다.)"

    # ------------------------------------------------------
    # 장면 5 — 교문 앞
    # ------------------------------------------------------
    scene black with fade
    
    
    scene cg_n1 with dissolve

    "다음 날 아침."
    "교문 앞에서 하린이를 기다렸다."
    "멀리서 하린이가 걸어오는 게 보였다."
    "어깨는 여전히 좀 굽어 있었다."
    "그래도 오늘은 나를 보자 눈이 잠깐 빛났다."
   
    h "...왔네."

    n "응. 왔어."

    "그게 전부였다."
    "하지만 그거면 충분했다."

    stop music fadeout 3.0    
    scene black with fade
    pause 0.8

    centered "{size=34}{color=#FFFFFF99}엔딩{/color}{/size}\n\n{size=54}{color=#FFFFC8}{b}동행 엔딩: 혼자 두지 않은 용기{/b}{/color}{/size}\n\n{size=28}{color=#FFFBE8}한 사람이 곁에 남아 준 날들{/color}{/size}"
    pause 2.5

    jump ending_epilogue


# ==========================================================
# [경로 4] BAD END: 여전히 추운 교실
# ==========================================================
label ending_bad:
    $ ending_type = "bad"
    scene black with fade
    pause 0.6

    # ------------------------------------------------------
    # 장면 1 — 선생님의 한계
    # ------------------------------------------------------
    scene bg_17 with fade
    "선생님은 내 말을 허투루 듣지 않으셨다."
    "쉬는 시간마다 교실에 오셨고,"
    "하린이 자리를 바꿔주셨고,"
    "민재와 예서에게도 따로 주의를 주셨다."

    "그런데 그게 거기까지였다."

    "선생님이 보는 앞에서는 모든 게 조용했다."
    "민재와 예서는 '저희는 아무 짓도 안 했는데요?'라는 얼굴로 선생님을 바라봤고,"
    "하린이는 '괜찮아요'라고만 답했다."
    "소윤이는 끝까지 나와 눈도 마주치지 않았다."

    "같이 말해 줄 사람이 없었다."
    "나 혼자 본 것들은,"
    "말로 설명하려고 하면 할수록 점점 작아졌다."

    n "(내가 본 건 진짜였는데.)"
    n "(왜 나만 점점 이상한 사람이 되는 걸까.)"

    # ------------------------------------------------------
    # 장면 2 — 다시 퍼진 사진
    # ------------------------------------------------------
    scene black with fade

    "며칠 뒤."
    "그 일이 결국 터졌다."

    "예서가 방과 후에 협박하며 꺼냈던 그 사진이,"
    "반 단톡방에 '실수로 잘못 보냈다'는 이름으로 다시 올라왔다."
    "물론 실수가 아니라는 건 모두가 알았다."

    "ㅋㅋㅋㅋ 하는 댓글이 금방 줄줄이 달렸다."
    "예서는 곧바로 '아 미안 실수 실수'라며 사진을 지웠다."
    "하지만 이미 본 사람들의 머릿속에서는 지워지지 않았다."

    scene cg_b2 with dissolve
    "그날 하린이는 학교에 오지 않았다."
    "그다음 날도."
    "그다음 날도."

    # ------------------------------------------------------
    # 장면 3 — 혼자 남은 나
    # ------------------------------------------------------
    scene black with fade

    play music "audio/bad_end.mp3" fadein 2.0 fadeout 1.0
    scene cg_b1 with dissolve

    "하린이의 빈자리 앞에 서 있던 어느 쉬는 시간."
    "운동장에서 들려오는 소리가 유난히 크게 느껴졌다."
    "교실에서는 아무도 하린이에 대해 묻지 않았다."
    "그게 제일 이상했다."

    "'어? 하린이 왜 안 와?'"
    "'무슨 일 있었어?'"
    "그런 말 한마디가 누구의 입에서도 나오지 않았다."
    "어제까지 하린이 이름을 입에 달고 살던 민재도,"
    "오늘은 아무 일 없다는 듯 다른 애 얘기를 하고 있었다."
    "교실이 이렇게 빨리 잊어버릴 수 있다는 게,"
    "한 사람이 이렇게 빨리 없던 사람이 된다는 게 무서웠다."

    "그리고 며칠 뒤,"
    "하린이가 결국 전학을 간다는 소식이 전해졌다."

    # ------------------------------------------------------
    # 장면 4 — 주인공의 성찰
    # ------------------------------------------------------
    scene black with fade

    n "(선생님이 움직이지 않은 건 아니었어.)"
    n "(내가 말하지 않은 것도 아니었어.)"
    n "(근데 왜 이렇게 된 걸까.)"

    n "(…알 것 같아.)"
    n "(나 혼자 아는 것만으로는,)"
    n "(이 상황을 멈출 수 없었어.)"
    n "(함께 봐 줄 사람,)"
    n "(같이 말해 줄 사람이 필요했어.)"

    n "(그런데 나는,)" 
    n "(소윤이가 같이 말할 수 있을 만큼 안전하다고 느끼게 만들지 못했어.)"
    n "(하린이한테도, 천천히 다가가지 못했어.)"
    n "(내가 자꾸 앞서 나갔어.)"
    n "(급해서, 무서워서, 빨리 해결하고 싶어서.)"

    n "(그래서 둘 다 나한테 닿지 못한 거야.)"

    # ------------------------------------------------------
    # 장면 5 — 그날 밤
    # ------------------------------------------------------
    stop music fadeout 3.0
    scene bg_3 with fade

    "그날 밤, 나는 이불 속에서 오래 뒤척였다."
    "내일도 교실은 조용할 것이다."
    "민재는 학교에 올 것이고,"
    "예서도, 소윤이도, 모두 제자리에 있을 것이다."
    "바뀐 건 하린이의 자리 하나뿐이었다."

    "그게 제일 무서웠다."
    "한 명이 사라졌는데도,"
    "아무것도 크게 바뀌지 않는 교실이라는 게."

    n "(다음엔, 더 천천히.)"
    n "(다음엔, 더 제대로.)"
    n "(누군가 말할 수 있도록,)"
    n "(같이 말해 줄 사람이 먼저 되어야 해.)"

    n "(혼자 성급하게 영웅이 되려고 하지 말자.)"

    "그 생각을 마지막으로, 나는 무거운 눈을 감았다."
    "베개가 차갑게 젖어 있었다."

    
    scene black with fade
    pause 2.5

    centered "{size=34}{color=#FFFFFF99}엔딩{/color}{/size}\n\n{size=54}{color=#E8736C}{b}침묵 엔딩: 아직 차가운 교실{/b}{/color}{/size}\n\n{size=28}{color=#FFE1DE}함께 말하지 못해 남겨진 자리{/color}{/size}"
    pause 3.0

    jump ending_epilogue


# ==========================================================
# [경로 5] HIDDEN END: 장난과 폭력의 무게
# ==========================================================
label ending_hidden:
    $ ending_type = "hidden"

    scene black with fade
    pause 0.8

    # ------------------------------------------------------
    # HIDDEN EPILOGUE — TRUE END 이후
    # ------------------------------------------------------

    scene cg_b3 with dissolve
    "하린이가 조금씩 학교에 다시 적응하기 시작한 뒤에도,"
    "교실의 모든 문제가 한순간에 사라진 것은 아니었다."

    "선생님은 민재와 예서를 따로 만나 계속 이야기를 나누셨고,"
    "위클래스에서도 몇 번 더 상담이 이어졌다고 했다."

    "하린이는 예전보다 덜 움츠러들었지만,"
    "민재와 같은 공간에 있을 때면 여전히 시선을 마주치지 못했다."

    "나는 그게 당연하다고 생각했다."
    "하린이가 괜찮아지는 것과,"
    "민재가 자기 잘못을 아는 것은"
    "서로 다른 일이니까."

    scene black with fade
    pause 0.6

    # ------------------------------------------------------
    # 장면 1 — 2주 뒤, 뒷문에서
    # ------------------------------------------------------
    scene bg_14 with fade

    "그 일이 있은 지 2주쯤 지난 어느 날."
    "6교시가 끝나고 아이들이 거의 다 빠져나간 교실."
    "나는 가방을 챙기고 있었다."

    "그때, 뒷문 쪽에서 누가 작게 이름을 불렀다."

    scene bg_14_blur with dissolve
    show m12 at center_stage with dissolve
    m "...야. 잠깐."
    hide m12 with dissolve

    scene bg_14 with dissolve
    "민재였다."
    "나는 놀라서 돌아봤다."
    "민재는 평소처럼 가방끈을 한쪽 어깨에만 걸친 채 서 있었다."
    "그런데 표정이 완전히 달랐다."
    "늘 웃거나 찌푸리거나 하던 얼굴이,"
    "오늘은 달랐다."

    scene bg_14_blur with dissolve
    show m5 at center_stage with dissolve
    m "혹시… 하린이한테 말 좀 전해줄 수 있어?"
    m "…아니다. 그러면 안 되지."
    m "내일 방과 후에, 하린이랑 잠깐 얘기할 수 있을까."
    m "네가 옆에 있어도 돼."
    hide m5 with dissolve

    # ------------------------------------------------------
    # 장면 2 — 다음 날, 교실 뒤
    # ------------------------------------------------------
    scene black with fade
    pause 0.8

    play music "audio/bgm_hidden_reflective.mp3" fadein 3.0 volume 0.5
    scene cg_h1 with fade

    "다음 날 방과 후."
    "교실 뒤쪽, 사물함이 있는 구석."
    "하린이, 소윤이, 나, 그리고 민재가 서 있었다."

    "소윤이는 내가 부르지 않아도 와 있었다. 하린이 옆에 서서, 아무 말 없이."

    "민재는 한참 동안 바닥만 봤다."
    "어떻게 입을 떼야 하는지 모르는 사람처럼."
    "그러다 겨우 작게 말했다."

    m "...하린아."
    m "그동안 내가 했던 거. 진짜 미안해."
  
    "하린이는 대답하지 않았다."
    "하린이 옆에 선 소윤이도 말이 없었다."
    "민재는 그 침묵을 견디면서, 계속 말을 이어갔다."

    m "처음엔 그냥…"
    m "애들 웃기려고 한 거였어."
    m "네가 반응이 없으니까 더 쉬워 보였고,"

    m "애들이 웃어주니까 나는 뭔가 된 것 같았어."
    m "한 번은 그만하고 싶다고 생각했어."
    m "근데 그만두면 내가 이상한 애 될 것 같아서 무서웠어."
    m "그래서 계속 갔어. 계속."
 
    "민재의 목소리가 조금씩 떨리기 시작했다."
    "늘 떠들썩하던 그 민재가,"
    "자기 목소리를 제대로 가누지 못하는 모습이 낯설었다."

    m "지금 생각하면 다 변명이야."
    m "내가 너한테 한 건 장난이 아니었어."
    m "그냥 괴롭힘이었어. 그게 맞아."
    m "…네가 나 용서 안 해도 돼."

    m "용서받으려고 하는 말 아니야."
    m "그냥, 내가 한 짓이 뭐였는지,"
    m "너한테 제대로 말은 해야 될 것 같아서."
    
    scene cg_h1_blur with dissolve
    show h3 at center_stage with dissolve
    "하린이는 여전히 말이 없었다."
    "고개를 들지도 않았다."
    "민재는 고개를 숙인 채로, 그 대답을 기다렸다."

    "한참 뒤, 하린이가 아주 작게 말했다."

    hide h3 with dissolve
    show h21 at center_stage with dissolve
    h "…나 네가 미웠어."
    h "진짜 많이 미웠어."
    h "지금도 미워."
  
    "민재는 고개를 들지 않았다."
    h "…용서는 못 해. 아직은."

    hide h21 with dissolve
    show h3 at center_stage with dissolve
    h "그래도, 말해줘서…"
    h "말해줘서 고마워."
  
    hide h3 with dissolve
    scene cg_h1 with dissolve
    "마지막 말은 하린이 자신도 놀란 것 같은 목소리였다."
    "고맙다는 말이 하고 싶어서 한 게 아니라,"
    "어쩌다 입 밖으로 나와버린 말 같았다."

    "민재는 허리를 굽혀 깊게 인사했다."

    "그리고 아무 말도 하지 못하고 교실을 나갔다."


    # ------------------------------------------------------
    # 장면 4 — 주인공의 독백
    # ------------------------------------------------------
    scene black with fade

    n "(나는 오랫동안, 민재를 '나쁜 애'라고만 생각했다.)"
    n "(그게 편했다. 민재가 나쁜 애면, 내가 고민할 것도 없으니까.)"

    n "(근데 오늘 민재는 나쁜 애도 아니고, 착한 애도 아니었다.)"
    n "(자기가 뭘 잘못했는지 똑바로 볼 수 있는 사람이었다.)"
    n "(그게 제일 어려운 거라는 걸, 이제는 안다.)"

    n "(용서는 하린이가 하는 거다. 내가 하는 게 아니다.)"
    n "(용서받으려고 하는 사과는, 진짜 사과가 아니니까.)"
    n "(민재는 용서받으려고 온 게 아니라,)"
    n "(자기가 한 일을 똑바로 말하러 온 거였다.)"

    n "(그거 하나만으로도,)"
    n "(이 교실은 전보다 조금 더 안전한 곳이 된 것 같다.)"

    # ------------------------------------------------------
    # 장면 5 — 담임의 말
    # ------------------------------------------------------
    scene black with fade
    pause 0.5

    scene bg_17 with fade
    "그날 종례 시간, 선생님이 평소처럼 짧게 말씀하셨다."

    scene bg_17_blur with dissolve
    show t5 at center_stage with dissolve
    t "얘들아, 사과는 한 번으로 끝나지 않아."
    t "진짜 사과는, 그 뒤의 행동으로 증명되는 거야."
    t "말만 하고 다시 똑같이 굴면, 그건 사과가 아니라 변명이야."
    hide t5 with dissolve
    show t6 at center_stage with dissolve
    t "그러니까 사과를 받은 사람도,"
    t "'고마워, 다 괜찮아'라고 억지로 말하지 않아도 돼."
    t "미운 건 미운 거야. 그 마음도 네 거야."
    hide t6 with dissolve

    scene bg_17 with dissolve
    "나는 슬쩍 하린이 쪽을 봤다."

    scene bg_17_blur with dissolve
    show h10 at center_stage with dissolve
    "하린이는 가방을 꼭 안은 채 고개를 숙이고 있었다."
    "입을 꾹 다물고 있는 그 표정이,"
    "뭔가를 오래 눌러왔던 사람이 처음으로 '그래도 된다'는 말을 들은 얼굴 같았다."
    hide h10 with dissolve

    # ------------------------------------------------------
    # 장면 6 — 완전히 닫지 않은 마음
    # ------------------------------------------------------
    scene black with fade
    pause 0.4

    "며칠 뒤, 하교 준비를 마치고 교실을 나서려던 때였다."

    scene cg_h2 with dissolve
    "복도에 하린이와 민재가 조금 떨어진 채 마주 서 있었다."
    "둘 사이에는 여전히 조심스러운 공기가 남아 있었다."


    m "…저번에 말한 거, 그냥 형식적으로 한 거 아니야."
    m "네가 바로 괜찮아져야 한다고 생각하지도 않아."
    m "근데 내가 한 일은 안 잊을 거야."
    m "앞으로는 진짜로 다르게 행동할게."


    "하린이는 한동안 대답하지 않았다."
    "예전 같으면 고개를 더 숙인 채 그대로 지나쳤을지도 모른다."
    "하지만 이번엔 달랐다."

    h "…나 아직 하나도 안 괜찮아."
    h "네가 한 말 듣고 바로 괜찮아질 수도 없어."

    h "근데…"
    h "네가 진짜로 바뀌려는 건지,"
    h "그건… 조금 더 보고 싶어."

    "민재는 아무 말도 하지 못한 채 잠깐 눈을 깜빡였다."

    m "응."
    m "그렇게 해."

    "민재는 더 변명하지 않고 먼저 고개를 숙였다."

    "하린이는 곧장 웃지 않았다."
    "마음이 풀린 것도 아니었다."
    "하지만 적어도 이번에는,"
    "민재의 말을 끝까지 들어주었다."

    n "(용서는 바로 되는 게 아니다.)"
    n "(다만 오늘 하린이는,)"
    n "(자기 마음을 숨기지 않은 채 상대의 말을 끝까지 듣기로 선택했다.)"
    n "(그리고 그 선택은 하린이의 것이었다.)"

    stop music fadeout 3.0
    scene black with fade
    pause 0.8

    centered "{size=34}{color=#FFFFFF99}엔딩{/color}{/size}\n\n{size=54}{color=#C8C8FF}{b}성찰 엔딩: 사과는 끝이 아니라 시작{/b}{/color}{/size}\n\n{size=28}{color=#F0F0FF}장난이라고 부른 폭력의 무게{/color}{/size}"
    pause 2.5

    jump ending_epilogue


# ==========================================================
# 에필로그 — 공통
# ==========================================================
label ending_epilogue:
    scene black with fade
    pause 0.6

    "텅 빈 교실."
    "창가로 햇빛이 길게 들어온다."
    "하린이의 자리가 보인다."

    if ending_type == "bad":
        scene cg_1 with dissolve
        "오늘, 그 자리는 비어 있다."
        "그리고 그 비어 있음이, 어떤 교실에서는 너무 조용하게 넘어간다."
    else:
        scene bg_14 with fade
        "오늘, 그 자리엔 희미한 온기가 남아 있다."
        "책가방을 두고 간 하린이의 흔적이다."
        "이제 더 이상 비어 보이지 않는 자리."

    scene black with fade

    n "안녕?"
    n "여기까지 나랑 하린이의 이야기를 함께해 줘서 고마워."

    n "처음엔 그냥 '운이 나쁜 애' 이야기라고 생각했을 수도 있어."
    n "원래 교실은 이런 곳이니까, 하고 넘겼을지도 모르지."

    n "하지만 하린이는 운이 나빴던 게 아니야."
    n "우리가 한 번 덜 쳐다보고,"
    n "한 번 덜 물어보고,"
    n "한 번 덜 옆에 앉았던 그 순간들이 쌓여서,"
    n "누군가를 조금씩 교실 밖으로 밀어내고 있었던 거야."

    n "네가 게임을 하면서 멈칫했던 순간들 기억나?"
    n "'이거 말해도 되나?'"
    n "'내가 끼어들어도 되나?'"
    n "'내가 너무 오버하는 건가?'"

    n "그때 네가 고른 선택이,"
    n "이 이야기의 결말을 만든 거야."

    play music "audio/bgm_epilogue_soft.mp3" fadein 4.0 volume 0.6

    if ending_type == "true":
        n "이번엔 끝까지 갔어. 너랑 내가 함께."
        n "아주 크게 바뀐 건 아니지만,"
        n "하린이가 다시 웃었어."
        n "그거면 충분해."
    elif ending_type == "hidden":
        n "이번엔 끝까지 갔어. 그리고 한 걸음 더 갔어."
        n "그 사람이 자기가 한 일을 똑바로 볼 수 있게 만드는 것"
        n "그것까지가 우리가 해낸 일이야."
    elif ending_type == "step_a":
        n "이번엔 한 사람을 밀어내던 분위기를 멈추게 했어."
        n "근데 하린이의 마음은 아직 아물고 있는 중이야."
        n "그건 우리가 '실패한' 게 아니라,"
        n "원래 시간이 걸리는 일이야."
        n "조급해하지 말자. 지금 충분히 잘하고 있어."
    elif ending_type == "normal":
        n "이번엔 교실 전체를 바꾸진 못했어."
        n "근데 하린이 한 명은 혼자 두지 않았어."
        n "그거, 생각보다 엄청난 일이야."
        n "한 사람의 진심이 한 사람을 붙잡을 수 있다는 거."
    else:
        n "이번엔 끝까지 가지 못했어."
        n "근데 괜찮아. 여기서 포기하지만 않으면 돼."
        n "다음엔, 더 천천히. 더 제대로."
        n "혼자 뛰어들지 말고, 옆에 함께할 사람을 먼저 만들자."

    scene black with fade


    n "이 이야기는 여기서 끝나는 이야기가 아니야."
    n "어디선가 비슷한 순간이 또 올 거야."
    n "누가 말을 못 하고 있을 때."
    n "누가 웃고 있는데 눈이 안 웃고 있을 때."
    n "누가 급식실에서 혼자 구석 자리로 걸어갈 때."

    n "그때,"
    n "그냥 지나칠지, 한 번 더 볼지."
    n "말을 걸어 볼지, 옆에 앉아 볼지."
    n "그건 네가 선택하는 거야."

    n "그 선택이 무겁다고 느껴질 수도 있어."
    n "근데 기억해 줘."
    n "네가 내민 아주 작은 손이,"
    n "누군가한테는 다시 학교에 올 수 있는 이유가 될 수도 있다는 걸."

    if ending_type == "bad":
        n "나는 아직 이 장면을 끝이라고 생각하지 않을 거야."
        n "다음에는 혼자 서두르지 않고, 함께 말할 사람을 만들 거야."
    else:
        n "나는 이제 다시 시간을 돌리지 않아도 돼."
        n "이번엔 너와 함께 끝까지 왔으니까."

    n "그럼, 또 봐."

    hide screen quick_note_button

    stop music fadeout 5.0

    scene black with fade
    pause 5.0

    jump project_finish

############################################################
   
label project_finish:    
    scene black with dissolve
    "PROJECT FINISHED: 복도 끝의 신호"
    "제작: 젼쌤"
    return

